// Design system reference + remaining detail screens

const DesignSystem = () => (
  <div style={{ padding: 32, background: 'var(--surface)', minHeight: '100%' }}>
    <header style={{ marginBottom: 32, paddingBottom: 24, borderBottom: '1px solid var(--border-2)' }}>
      <div className="muted tiny" style={{ marginBottom: 6, fontFamily: 'var(--font-mono)' }}>FAITH COMMUNITY · v1.0</div>
      <h1 className="display" style={{ fontSize: 40, marginBottom: 8 }}>Design System</h1>
      <p className="muted" style={{ maxWidth: 560 }}>Tokens, components, and rules. Implemented as Tailwind utility classes + small set of Rails ERB partials.</p>
    </header>

    <section style={{ marginBottom: 36 }}>
      <h2 style={{ font: '600 18px var(--font-sans)', marginBottom: 14 }}>Color tokens</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6,1fr)', gap: 10 }}>
        {[
          ['Background','--bg','#f6f3ec'],
          ['Surface','--surface','#fdfcf8'],
          ['Surface-2','--surface-2','#f9f6ee'],
          ['Border','--border','#d9d4c3'],
          ['Ink','--ink','#1c2a22'],
          ['Muted','--muted','#6b7d6e'],
          ['Primary','--primary','#2f5a45'],
          ['Primary soft','--primary-soft','#dde7d8'],
          ['Accent','--accent','#b08740'],
          ['Accent soft','--accent-soft','#efe2c4'],
          ['Danger','--danger','#a54b3b'],
          ['Success','--success','#4d7a4c'],
        ].map(([n,t,h]) => (
          <div key={n}>
            <div style={{ aspectRatio: '4/3', borderRadius: 8, background: h, border: '1px solid var(--border-2)' }} />
            <div style={{ fontSize: 12, fontWeight: 600, marginTop: 6 }}>{n}</div>
            <div className="muted tiny" style={{ fontFamily: 'var(--font-mono)' }}>{t}</div>
            <div className="muted tiny" style={{ fontFamily: 'var(--font-mono)' }}>{h}</div>
          </div>
        ))}
      </div>
    </section>

    <section style={{ marginBottom: 36 }}>
      <h2 style={{ font: '600 18px var(--font-sans)', marginBottom: 14 }}>Room tints</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6,1fr)', gap: 10 }}>
        {SAMPLE.rooms.map(r => (
          <div key={r.name} style={{ background: `var(--r-${r.color}-bg)`, color: `var(--r-${r.color}-fg)`, padding: 14, borderRadius: 10 }}>
            <Icon name={r.icon} size={18} />
            <div style={{ fontWeight: 600, fontSize: 13, marginTop: 8 }}>{r.name}</div>
            <div className="tiny" style={{ fontFamily: 'var(--font-mono)', opacity: 0.8 }}>--r-{r.color}-bg/fg</div>
          </div>
        ))}
      </div>
    </section>

    <section style={{ marginBottom: 36 }}>
      <h2 style={{ font: '600 18px var(--font-sans)', marginBottom: 14 }}>Type</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div className="display" style={{ fontSize: 48, lineHeight: 1.1 }}>Display 48 / Fraunces</div>
        <div className="display" style={{ fontSize: 32 }}>Display 32 / Fraunces</div>
        <div className="serif" style={{ fontSize: 22 }}>Serif 22 / Cormorant — for blockquotes & post body</div>
        <div style={{ font: '600 18px var(--font-sans)' }}>UI 18 semibold / Geist Sans</div>
        <div style={{ font: '500 14px var(--font-sans)' }}>UI 14 / Geist Sans — body</div>
        <div className="muted tiny">UI 12 / muted — metadata</div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}>FONT-MONO 12 / Geist Mono — labels & data</div>
      </div>
    </section>

    <section style={{ marginBottom: 36 }}>
      <h2 style={{ font: '600 18px var(--font-sans)', marginBottom: 14 }}>Buttons & badges</h2>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginBottom: 14 }}>
        <button className="btn btn-primary">Primary</button>
        <button className="btn btn-secondary">Secondary</button>
        <button className="btn btn-ghost">Ghost</button>
        <button className="btn btn-danger">Danger</button>
        <button className="btn btn-primary btn-sm">Small</button>
        <button className="btn btn-primary btn-lg">Large</button>
        <button className="btn btn-secondary btn-icon"><Icon name="bookmark" size={14} /></button>
      </div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        <span className="badge">Default</span>
        <RoomBadge room="Prayer" />
        <RoomBadge room="Testimony" />
        <RoomBadge room="Bible Study" />
        <span className="badge badge-mod">Moderator</span>
        <span className="badge badge-admin">Admin</span>
        <span className="chip active">Active chip</span>
        <span className="chip">Filter chip</span>
      </div>
    </section>

    <section style={{ marginBottom: 36 }}>
      <h2 style={{ font: '600 18px var(--font-sans)', marginBottom: 14 }}>Reactions</h2>
      <ReactionRow counts={{ amen: 47, praying: 12, encourage: 8, love: 22, inspired: 4 }} active="amen" />
    </section>

    <section style={{ marginBottom: 36 }}>
      <h2 style={{ font: '600 18px var(--font-sans)', marginBottom: 14 }}>Spacing & radius scale</h2>
      <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
        {[4,8,12,16,20,24,32,40,48].map(s => (
          <div key={s} style={{ textAlign: 'center' }}>
            <div style={{ width: s, height: s, background: 'var(--primary)', borderRadius: 3, margin: '0 auto' }} />
            <div className="tiny muted" style={{ marginTop: 6, fontFamily: 'var(--font-mono)' }}>{s}</div>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 14, marginTop: 18 }}>
        {[6,10,14,999].map(r => (
          <div key={r} style={{ width: 60, height: 60, borderRadius: r, background: 'var(--surface-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--muted)', paddingBottom: 4 }}>{r === 999 ? 'pill' : r}</div>
        ))}
      </div>
    </section>

    <section>
      <h2 style={{ font: '600 18px var(--font-sans)', marginBottom: 14 }}>Implementation notes</h2>
      <div className="muted" style={{ fontSize: 13.5, lineHeight: 1.6, maxWidth: 720 }}>
        <p>Tokens map 1:1 to Tailwind theme extensions in <code style={{ fontFamily: 'var(--font-mono)' }}>tailwind.config.js</code>. Components ship as ERB partials in <code style={{ fontFamily: 'var(--font-mono)' }}>app/views/shared/</code> — one per primitive (post_card, room_badge, reaction_row, etc.).</p>
        <p>Use Stimulus controllers for: reaction picker (<code style={{ fontFamily: 'var(--font-mono)' }}>data-controller="reactions"</code>), bookmark toggle, mention typeahead, image upload preview. Hotwire/Turbo Frames cover feed pagination, comment threads, and notification list.</p>
      </div>
    </section>
  </div>
);

// Brethren card edit + connection requests + resource detail
const BrethrenEdit = () => (
  <div className="page">
    <TopNav />
    <div style={{ maxWidth: 720, margin: '0 auto', padding: '24px', width: '100%' }}>
      <PageHeader title="Brethren Card" subtitle="Shared only with people whose connection requests you accept." breadcrumb="Settings → Brethren Card" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 240px', gap: 16, marginTop: 16 }}>
        <div className="card" style={{ padding: 24 }}>
          <div style={{ marginBottom: 20 }}>
            <div className="muted tiny" style={{ marginBottom: 4 }}>Completion · 4 of 5 fields</div>
            <div style={{ height: 6, borderRadius: 999, background: 'var(--surface-2)' }}>
              <div style={{ width: '80%', height: '100%', borderRadius: 999, background: 'var(--primary)' }} />
            </div>
          </div>
          {[
            ['Church / Assembly','Christ Church Lagos · Anglican'],
            ['Bio','Husband to Tola, dad to two. Trying to do small things faithfully.', 'textarea'],
            ['Occupation','Software engineer at Paystack'],
            ['WhatsApp number','+234 80 ••• 4729'],
            ['Email','daniel.okafor@example.com'],
          ].map(([l,v,k]) => (
            <div key={l} style={{ marginBottom: 14 }}>
              <label className="muted tiny" style={{ display: 'block', marginBottom: 4 }}>{l}</label>
              {k === 'textarea' ? <textarea className="input textarea" defaultValue={v} /> : <input className="input" defaultValue={v} />}
            </div>
          ))}
          <div style={{ display: 'flex', gap: 8, marginTop: 16, justifyContent: 'flex-end' }}>
            <button className="btn btn-ghost btn-sm">Discard</button>
            <button className="btn btn-primary btn-sm">Save card</button>
          </div>
        </div>
        <aside>
          <div className="card" style={{ padding: 14 }}>
            <Icon name="shield" size={16} style={{ color: 'var(--primary)', marginBottom: 8 }} />
            <div style={{ font: '600 13px var(--font-sans)', marginBottom: 6 }}>How sharing works</div>
            <p className="muted" style={{ fontSize: 13, lineHeight: 1.5 }}>Your card stays private until you accept someone's "Can I know you more?" request. They share theirs back at the same time.</p>
          </div>
        </aside>
      </div>
    </div>
  </div>
);

const ConnectionRequests = () => (
  <div className="page">
    <TopNav active="connections" />
    <div style={{ maxWidth: 760, margin: '0 auto', padding: '24px', width: '100%' }}>
      <PageHeader title="Connection requests" subtitle="Review carefully — both cards are shared on accept." />
      <div className="tabs" style={{ marginTop: 12, marginBottom: 16 }}>
        <div className="tab active">Incoming · 3</div>
        <div className="tab">Sent · 5</div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {['Joseph Adei','Ruth Mwangi','Hannah Reyes'].map((n,i) => (
          <div key={n} className="card" style={{ padding: 16, display: 'flex', gap: 14, alignItems: 'flex-start' }}>
            <Avatar name={n} size="lg" />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <span style={{ fontWeight: 600 }}>{n}</span>
                <span className="muted tiny">@{n.toLowerCase().split(' ')[0]} · 2 mutual rooms</span>
              </div>
              <p className="muted" style={{ fontSize: 13.5, margin: 0, fontStyle: 'italic' }}>"{['I really appreciated your post on grace. Would love to stay in touch.','Hi! We commented on the same prayer thread last week.','Sister! Found your testimony beautiful. Would love to know more.'][i]}"</p>
              <div className="muted tiny" style={{ marginTop: 8 }}>Card complete · sent 3h ago</div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <button className="btn btn-primary btn-sm">Accept</button>
              <button className="btn btn-secondary btn-sm">Decline</button>
              <button className="btn btn-ghost btn-sm" style={{ fontSize: 12 }}>View profile</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const ResourceDetail = () => (
  <div className="page">
    <TopNav active="resources" />
    <div style={{ maxWidth: 880, margin: '0 auto', padding: '24px', width: '100%' }}>
      <a className="muted tiny" style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginBottom: 16 }}><Icon name="chev_l" size={12} /> Library / Prayer</a>
      <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr', gap: 28 }}>
        <div>
          <div style={{ aspectRatio: '3/4', borderRadius: 12, background: 'var(--r-prayer-bg)', color: 'var(--r-prayer-fg)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
            <Icon name="pdf" size={56} />
          </div>
          <button className="btn btn-primary btn-lg" style={{ width: '100%', marginBottom: 8 }}><Icon name="download" size={14} /> Download PDF</button>
          <button className="btn btn-secondary btn-sm" style={{ width: '100%' }}><Icon name="bookmark" size={13} /> Save to bookmarks</button>
          <div className="muted tiny" style={{ marginTop: 14, lineHeight: 1.6 }}>
            <div>1,284 downloads</div>
            <div>4,201 views</div>
            <div>Approved May 1, 2026</div>
          </div>
        </div>
        <div>
          <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
            <span className="badge" style={{ background: 'var(--r-prayer-bg)', color: 'var(--r-prayer-fg)', border: 0 }}><Icon name="pdf" size={11}/> PDF</span>
            <span className="badge">Prayer</span>
            <span className="badge"><Icon name="pin" size={10}/> Featured</span>
          </div>
          <h1 className="display" style={{ fontSize: 32, lineHeight: 1.15, marginBottom: 12 }}>Praying with the Psalms — a 30 day guide</h1>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 18 }}>
            <Avatar name="Eugene H" size="sm" />
            <div className="muted tiny">Submitted by Eugene H. · @eugene · approved 2026</div>
          </div>
          <p className="serif" style={{ fontSize: 16, color: 'var(--ink-2)', lineHeight: 1.65, marginBottom: 18 }}>A daily practice for praying through the Psalter, paced for busy seasons. Includes a printable booklet, a Sunday-rest variant, and notes on praying through grief, fear, and joy.</p>
          <h3 style={{ font: '600 14px var(--font-sans)', marginBottom: 10 }}>What's inside</h3>
          <ul style={{ paddingLeft: 18, fontSize: 14, color: 'var(--ink-2)', lineHeight: 1.7, marginBottom: 18 }}>
            <li>30 daily prompts (5–10 min)</li>
            <li>Sunday rest variant</li>
            <li>Notes for hard seasons</li>
            <li>Printable A5 booklet</li>
          </ul>
          <h3 style={{ font: '600 14px var(--font-sans)', marginBottom: 10 }}>Related</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {SAMPLE.resources.slice(2,5).map(r => (
              <div key={r.title} className="card" style={{ padding: 12, display: 'flex', gap: 10, alignItems: 'center' }}>
                <span style={{ width: 32, height: 32, borderRadius: 6, background: TYPE_TINT[r.type][0], color: TYPE_TINT[r.type][1], display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Icon name={TYPE_ICON[r.type]} size={14}/></span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{r.title}</div>
                  <div className="muted tiny">{r.author}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);

const EmptyStates = () => (
  <div style={{ padding: 32, background: 'var(--bg)', minHeight: '100%' }}>
    <h1 style={{ font: '600 22px var(--font-sans)', marginBottom: 4 }}>Empty states</h1>
    <p className="muted" style={{ marginBottom: 24 }}>Tone matters more than copy length here.</p>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 14 }}>
      {[
        { icon: 'feed', title: 'Your following feed is quiet', body: "You aren't following anyone yet. Start with a few people from rooms you visit.", cta: <button className="btn btn-primary btn-sm">Browse rooms</button> },
        { icon: 'bookmark', title: 'No bookmarks yet', body: 'Save posts to read them later. They show up here, not on your profile.' },
        { icon: 'bell', title: "You're caught up", body: 'No new notifications. We only notify you for replies, mentions, and connection requests.' },
        { icon: 'users', title: 'No connections yet', body: 'Connection requests start with a "Can I know you more?" on a profile. Cards are shared mutually on accept.' },
        { icon: 'search', title: 'Search the community', body: 'Find posts, people, and resources. Try "psalms", "@danielo", or "sabbath".' },
        { icon: 'flag', title: 'No reports to review', body: 'Members are kind. When something needs attention, it shows up here.' },
      ].map((e,i) => (
        <div key={i} className="card"><EmptyState {...e} /></div>
      ))}
    </div>
  </div>
);

window.DesignSystem = DesignSystem;
window.BrethrenEdit = BrethrenEdit;
window.ConnectionRequests = ConnectionRequests;
window.ResourceDetail = ResourceDetail;
window.EmptyStates = EmptyStates;

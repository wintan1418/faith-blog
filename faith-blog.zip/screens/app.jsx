
const { useState, useEffect } = React;

// Wrap a desktop screen so it always lays out at full design width
const Frame = ({ w = 1280, h = 820, children }) => (
  <div style={{ width: w, height: h, background: 'var(--bg)', overflow: 'hidden', borderRadius: 8, position: 'relative' }}>
    <div style={{ width: w, height: h, overflow: 'auto' }}>{children}</div>
  </div>
);

// Phone-shaped frame for mobile screens
const Phone = ({ children }) => (
  <div style={{ width: 320, height: 680, background: 'var(--surface)', borderRadius: 28, border: '8px solid #1c2a22', overflow: 'hidden', position: 'relative' }}>
    <div style={{ width: '100%', height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>{children}</div>
  </div>
);

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "warm",
  "primaryHue": 145,
  "density": "comfortable",
  "reactionStyle": "emoji-label",
  "roomColorTreatment": "tinted-hero",
  "navVariant": "top"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);

  // Apply theme
  useEffect(() => {
    const root = document.documentElement;
    if (tweaks.theme === 'dark') {
      root.style.setProperty('--bg', '#181f1c');
      root.style.setProperty('--surface', '#21282480');
      root.style.setProperty('--ink', '#e8ebe5');
    } else if (tweaks.theme === 'cool') {
      root.style.setProperty('--bg', '#eef0ec');
      root.style.setProperty('--surface', '#fbfcfa');
    } else {
      root.style.removeProperty('--bg');
      root.style.removeProperty('--surface');
      root.style.removeProperty('--ink');
    }
    const hue = tweaks.primaryHue;
    root.style.setProperty('--primary', `oklch(0.42 0.07 ${hue})`);
    root.style.setProperty('--primary-2', `oklch(0.36 0.07 ${hue})`);
    root.style.setProperty('--primary-soft', `oklch(0.92 0.04 ${hue})`);
  }, [tweaks.theme, tweaks.primaryHue]);

  return (
    <>
      <DesignCanvas background="#0f1714" gridDot="#2c3a32">
        <DCSection id="ds" title="Design system" subtitle="Tokens, components, and visual rules — start here">
          <DCArtboard id="tokens" label="Tokens & components" width={960} height={1400}>
            <Frame w={960} h={1400}><DesignSystem /></Frame>
          </DCArtboard>
          <DCArtboard id="empty" label="Empty states" width={760} height={620}>
            <Frame w={760} h={620}><EmptyStates /></Frame>
          </DCArtboard>
        </DCSection>

        <DCSection id="landing" title="Public" subtitle="Landing, auth — warmer than app, same system">
          <DCArtboard id="landing" label="Landing — guest" width={1280} height={820}>
            <Frame><Landing /></Frame>
          </DCArtboard>
          <DCArtboard id="signin" label="Sign in" width={1100} height={680}>
            <Frame w={1100} h={680}><SignIn /></Frame>
          </DCArtboard>
        </DCSection>

        <DCSection id="feed" title="Feed — 3 variations" subtitle="Pick canonical layout for /feed">
          <DCArtboard id="feed-classic" label="A · Classic 3-column" width={1280} height={1100}>
            <Frame w={1280} h={1100}><FeedClassic /></Frame>
          </DCArtboard>
          <DCArtboard id="feed-editorial" label="B · Single-column editorial" width={1280} height={1100}>
            <Frame w={1280} h={1100}><FeedEditorial /></Frame>
          </DCArtboard>
          <DCArtboard id="feed-compact" label="C · Compact density" width={1280} height={1100}>
            <Frame w={1280} h={1100}><FeedCompact /></Frame>
          </DCArtboard>
        </DCSection>

        <DCSection id="post" title="Post" subtitle="Detail + composer">
          <DCArtboard id="post-detail" label="Post detail" width={1280} height={1700}>
            <Frame w={1280} h={1700}><PostDetail /></Frame>
          </DCArtboard>
          <DCArtboard id="post-new" label="New post" width={1280} height={1100}>
            <Frame w={1280} h={1100}><PostComposer /></Frame>
          </DCArtboard>
        </DCSection>

        <DCSection id="rooms" title="Rooms — 3 variations" subtitle="Index + tinted-hero detail + minimal">
          <DCArtboard id="rooms-index" label="Rooms index" width={1280} height={820}>
            <Frame><RoomsIndex /></Frame>
          </DCArtboard>
          <DCArtboard id="room-tinted" label="A · Tinted hero" width={1280} height={1100}>
            <Frame w={1280} h={1100}><RoomDetail /></Frame>
          </DCArtboard>
          <DCArtboard id="room-minimal" label="B · Minimal" width={1280} height={1100}>
            <Frame w={1280} h={1100}><RoomMinimal /></Frame>
          </DCArtboard>
        </DCSection>

        <DCSection id="profile" title="Profile + connections — 3 variations" subtitle="Card layout, visual layout, brethren card">
          <DCArtboard id="profile-card" label="A · Card layout" width={1280} height={1000}>
            <Frame w={1280} h={1000}><ProfileMain /></Frame>
          </DCArtboard>
          <DCArtboard id="profile-visual" label="B · Visual" width={1280} height={1000}>
            <Frame w={1280} h={1000}><ProfileVisual /></Frame>
          </DCArtboard>
          <DCArtboard id="brethren" label="C · Brethren Card (shared view)" width={680} height={820}>
            <Frame w={680} h={820}><BrethrenCard /></Frame>
          </DCArtboard>
          <DCArtboard id="brethren-edit" label="Brethren Card edit" width={1100} height={900}>
            <Frame w={1100} h={900}><BrethrenEdit /></Frame>
          </DCArtboard>
          <DCArtboard id="connections" label="My connections" width={1100} height={820}>
            <Frame w={1100} h={820}><ConnectionsScreen /></Frame>
          </DCArtboard>
          <DCArtboard id="connection-requests" label="Connection requests" width={1100} height={820}>
            <Frame w={1100} h={820}><ConnectionRequests /></Frame>
          </DCArtboard>
        </DCSection>

        <DCSection id="library" title="Library" subtitle="Resources index + detail">
          <DCArtboard id="library" label="Library home" width={1280} height={1100}>
            <Frame w={1280} h={1100}><Resources /></Frame>
          </DCArtboard>
          <DCArtboard id="resource" label="Resource detail" width={1100} height={820}>
            <Frame w={1100} h={820}><ResourceDetail /></Frame>
          </DCArtboard>
        </DCSection>

        <DCSection id="utility" title="Utility screens" subtitle="Search, notifications, bookmarks, settings">
          <DCArtboard id="search" label="Search" width={1100} height={1100}>
            <Frame w={1100} h={1100}><SearchScreen /></Frame>
          </DCArtboard>
          <DCArtboard id="notif" label="Notifications" width={900} height={780}>
            <Frame w={900} h={780}><Notifications /></Frame>
          </DCArtboard>
          <DCArtboard id="bookmarks" label="Bookmarks" width={900} height={1000}>
            <Frame w={900} h={1000}><Bookmarks /></Frame>
          </DCArtboard>
          <DCArtboard id="settings" label="Settings · Profile" width={1100} height={900}>
            <Frame w={1100} h={900}><Settings /></Frame>
          </DCArtboard>
        </DCSection>

        <DCSection id="admin" title="Admin" subtitle="Utilitarian, separate but related">
          <DCArtboard id="admin-dash" label="Admin dashboard" width={1280} height={1100}>
            <Frame w={1280} h={1100}><AdminDashboard /></Frame>
          </DCArtboard>
        </DCSection>

        <DCSection id="mobile" title="Mobile" subtitle="iPhone-sized layouts for every key screen">
          <DCArtboard id="m-feed" label="Feed" width={320} height={680}><Phone><MobileFeed /></Phone></DCArtboard>
          <DCArtboard id="m-post" label="Post detail" width={320} height={680}><Phone><MobilePost /></Phone></DCArtboard>
          <DCArtboard id="m-room" label="Room" width={320} height={680}><Phone><MobileRoom /></Phone></DCArtboard>
          <DCArtboard id="m-profile" label="Profile" width={320} height={680}><Phone><MobileProfile /></Phone></DCArtboard>
          <DCArtboard id="m-notif" label="Notifications" width={320} height={680}><Phone><MobileNotifications /></Phone></DCArtboard>
          <DCArtboard id="m-library" label="Library" width={320} height={680}><Phone><MobileLibrary /></Phone></DCArtboard>
          <DCArtboard id="m-compose" label="Compose" width={320} height={680}><Phone><MobileCompose /></Phone></DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Theme">
          <TweakRadio label="Mode" value={tweaks.theme} options={[['warm','Warm'],['cool','Cool'],['dark','Dark']]} onChange={v=>setTweak('theme', v)} />
          <TweakSlider label="Primary hue" min={80} max={200} step={5} value={tweaks.primaryHue} onChange={v=>setTweak('primaryHue', v)} />
        </TweakSection>
        <TweakSection title="Layout">
          <TweakRadio label="Density" value={tweaks.density} options={[['compact','Compact'],['comfortable','Comfy']]} onChange={v=>setTweak('density', v)} />
          <TweakRadio label="Nav" value={tweaks.navVariant} options={[['top','Top'],['side','Sidebar']]} onChange={v=>setTweak('navVariant', v)} />
        </TweakSection>
        <TweakSection title="Components">
          <TweakSelect label="Reactions" value={tweaks.reactionStyle} options={[['emoji-label','Emoji + label'],['icon-label','Icon + label'],['text','Text only']]} onChange={v=>setTweak('reactionStyle', v)} />
          <TweakSelect label="Room color" value={tweaks.roomColorTreatment} options={[['tinted-hero','Tinted hero + badge'],['badge-only','Badge only'],['neutral','All neutral']]} onChange={v=>setTweak('roomColorTreatment', v)} />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

function waitAndMount() {
  const needed = ['DesignCanvas','DCSection','DCArtboard','TweaksPanel','useTweaks','TweakSection','TweakSlider','TweakRadio','TweakSelect','FeedClassic','FeedEditorial','FeedCompact','PostDetail','PostComposer','RoomsIndex','RoomDetail','RoomMinimal','ProfileMain','ProfileVisual','BrethrenCard','BrethrenEdit','ConnectionsScreen','ConnectionRequests','Resources','ResourceDetail','SearchScreen','Notifications','Bookmarks','Settings','SignIn','Landing','AdminDashboard','MobileFeed','MobilePost','MobileRoom','MobileProfile','MobileNotifications','MobileLibrary','MobileCompose','DesignSystem','EmptyStates'];
  const missing = needed.filter(k => typeof window[k] === 'undefined');
  if (missing.length === 0) {
    ReactDOM.createRoot(document.getElementById('root')).render(<App />);
  } else {
    setTimeout(waitAndMount, 60);
  }
}
waitAndMount();

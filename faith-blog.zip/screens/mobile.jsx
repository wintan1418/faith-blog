// Mobile screens — phone-sized layouts using stack components

const MobileFeed = () => (
  <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--bg)' }}>
    <MobileTopBar title="Feed" />
    <div className="tabs" style={{ padding: '0 12px', background: 'var(--surface)', borderBottom: '1px solid var(--border-2)' }}>
      {['Recent','Trending','Following'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')} style={{ padding: '10px 8px', fontSize: 13 }}>{t}</div>)}
    </div>
    <div style={{ flex: 1, overflowY: 'auto', padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
      {SAMPLE.posts.slice(0,4).map(p => <PostCard key={p.id} post={p} />)}
    </div>
    <MobileBottomNav active="feed" />
  </div>
);

const MobilePost = () => {
  const p = SAMPLE.posts[0];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--surface)' }}>
      <div style={{ height: 48, borderBottom: '1px solid var(--border-2)', display: 'flex', alignItems: 'center', padding: '0 12px', gap: 10, background: 'var(--surface)' }}>
        <button className="btn btn-ghost btn-icon btn-sm"><Icon name="chev_l" size={16} /></button>
        <RoomBadge room={p.room} />
        <span style={{ marginLeft: 'auto' }}><button className="btn btn-ghost btn-icon btn-sm"><Icon name="dots" size={15} /></button></span>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '20px 16px' }}>
        <h1 className="display" style={{ fontSize: 26, lineHeight: 1.15, marginBottom: 14 }}>{p.title}</h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingBottom: 14, borderBottom: '1px solid var(--border-2)', marginBottom: 16 }}>
          <Avatar name={p.author} size="sm" />
          <div style={{ flex: 1, fontSize: 13 }}>
            <div style={{ fontWeight: 600 }}>{p.author}</div>
            <div className="muted tiny">2h · 4 min read</div>
          </div>
          <button className="btn btn-secondary btn-sm" style={{ height: 28, fontSize: 12 }}>Follow</button>
        </div>
        <div className="serif" style={{ fontSize: 16, lineHeight: 1.65 }}>
          <p style={{ marginTop: 0 }}>For years I thought I had to fix myself before I could come to Him. I'd read a verse, feel convicted, then white-knuckle a week of trying to be better — and quietly drift again.</p>
          <p style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontStyle: 'italic', borderLeft: '3px solid var(--accent)', paddingLeft: 12, color: 'var(--ink-2)' }}>"You hem me in behind and before…" — Psalm 139</p>
          <p>I'd read that verse a hundred times. That morning it landed like water.</p>
        </div>
      </div>
      <div style={{ borderTop: '1px solid var(--border-2)', padding: '10px 12px', display: 'flex', gap: 6, overflowX: 'auto', background: 'var(--surface)' }}>
        {REACTIONS.map(r => <button key={r.id} className="rxn"><span className="em">{r.em}</span><span style={{fontSize:11.5}}>{r.label}</span></button>)}
      </div>
      <div style={{ borderTop: '1px solid var(--border-2)', padding: '8px 12px', display: 'flex', gap: 4, background: 'var(--surface)' }}>
        <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}><Icon name="chat" size={14} /> 14</button>
        <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}><Icon name="repost" size={14} /> 6</button>
        <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}><Icon name="bookmark" size={14} /></button>
        <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}><Icon name="share" size={14} /></button>
      </div>
    </div>
  );
};

const MobileRoom = () => {
  const r = SAMPLE.rooms[1]; // Testimony
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--bg)' }}>
      <div style={{ background: `var(--r-${r.color}-bg)`, padding: '14px 16px', borderBottom: '1px solid var(--border-2)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <button className="btn btn-ghost btn-icon btn-sm"><Icon name="chev_l" size={16} /></button>
          <span style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
            <button className="btn btn-secondary btn-sm" style={{ height: 28, fontSize: 12 }}>Joined ✓</button>
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ width: 38, height: 38, borderRadius: 10, background: 'var(--surface)', color: `var(--r-${r.color}-fg)`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={r.icon} size={18} /></span>
          <div style={{ flex: 1 }}>
            <div style={{ font: '600 17px var(--font-sans)' }}>{r.name}</div>
            <div className="tiny" style={{ color: `var(--r-${r.color}-fg)`}}>{r.members.toLocaleString()} members · {r.posts.toLocaleString()} posts</div>
          </div>
        </div>
      </div>
      <div className="tabs" style={{ padding: '0 12px', background: 'var(--surface)' }}>
        {['Posts','Rules','Members'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')}>{t}</div>)}
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {SAMPLE.posts.slice(1,4).map(p => <PostCard key={p.id} post={p} />)}
      </div>
      <MobileBottomNav active="rooms" />
    </div>
  );
};

const MobileProfile = () => (
  <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--bg)' }}>
    <div style={{ height: 60, background: 'linear-gradient(135deg, var(--r-testimony-bg), var(--r-encourage-bg))' }} />
    <div style={{ padding: '0 16px 12px', marginTop: -28 }}>
      <Avatar name="Daniel Okafor" size="xl" />
      <div style={{ marginTop: 10, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <h1 style={{ font: '600 19px var(--font-sans)' }}>Daniel Okafor</h1>
            <span className="badge badge-mod" style={{ height: 18, fontSize: 10 }}>Mod</span>
          </div>
          <div className="muted tiny">@danielo · Lagos, NG</div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button className="btn btn-secondary btn-sm" style={{ height: 28, fontSize: 12 }}>Follow</button>
          <button className="btn btn-primary btn-sm" style={{ height: 28, fontSize: 12 }}>Connect</button>
        </div>
      </div>
      <p style={{ fontSize: 14, color: 'var(--ink-2)', margin: '10px 0' }}>Husband, dad, software eng. Trying to do small things faithfully.</p>
      <div style={{ display: 'flex', gap: 16, fontSize: 13 }}>
        <span><b>127</b> <span className="muted tiny">posts</span></span>
        <span><b>1.2k</b> <span className="muted tiny">followers</span></span>
        <span><b>312</b> <span className="muted tiny">following</span></span>
      </div>
    </div>
    <div className="tabs" style={{ padding: '0 12px', background: 'var(--surface)', borderBottom: '1px solid var(--border-2)' }}>
      {['Posts','Replies','Reactions'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')}>{t}</div>)}
    </div>
    <div style={{ flex: 1, overflowY: 'auto', padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
      {SAMPLE.posts.slice(0,3).map(p => <PostCard key={p.id} post={{...p, author: 'Daniel Okafor'}} />)}
    </div>
    <MobileBottomNav active="profile" />
  </div>
);

const MobileNotifications = () => (
  <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--bg)' }}>
    <div style={{ height: 52, background: 'var(--surface)', borderBottom: '1px solid var(--border-2)', display: 'flex', alignItems: 'center', padding: '0 12px', gap: 8 }}>
      <button className="btn btn-ghost btn-icon btn-sm"><Icon name="chev_l" size={16} /></button>
      <span style={{ font: '600 15px var(--font-sans)' }}>Notifications</span>
      <button className="btn btn-ghost btn-sm" style={{ marginLeft: 'auto', fontSize: 12 }}>Mark read</button>
    </div>
    <div className="tabs" style={{ padding: '0 12px', background: 'var(--surface)', borderBottom: '1px solid var(--border-2)' }}>
      {['All','Mentions','Connections'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')}>{t}</div>)}
    </div>
    <div style={{ flex: 1, overflowY: 'auto', background: 'var(--surface)' }}>
      {SAMPLE.notifications.map((n,i) => (
        <div key={i} style={{ display: 'flex', gap: 10, padding: '12px 14px', borderBottom: '1px solid var(--border-2)', background: n.unread ? 'var(--surface-2)' : 'transparent' }}>
          <Avatar name={n.actor} size="sm" />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13 }}><b>{n.actor}</b> {n.text}</div>
            <div className="muted tiny" style={{ marginTop: 2 }}>{n.time} ago</div>
          </div>
          {n.unread && <span style={{ width: 7, height: 7, borderRadius: 999, background: 'var(--accent)', alignSelf: 'center' }} />}
        </div>
      ))}
    </div>
    <MobileBottomNav />
  </div>
);

const MobileLibrary = () => (
  <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--bg)' }}>
    <MobileTopBar title="Library" />
    <div style={{ padding: '12px 12px 0' }}>
      <div style={{ position: 'relative' }}>
        <Icon name="search" size={14} style={{ position: 'absolute', left: 12, top: 11, color: 'var(--muted)' }} />
        <input className="input" placeholder="Search library" style={{ paddingLeft: 32 }} />
      </div>
      <div style={{ display: 'flex', gap: 6, padding: '12px 0', overflowX: 'auto' }}>
        {['All','PDF','Video','Audio','Book','Link'].map((c,i) => <button key={c} className={'chip' + (i===0?' active':'')} style={{ flexShrink: 0 }}>{c}</button>)}
      </div>
    </div>
    <div style={{ flex: 1, overflowY: 'auto', padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
      {SAMPLE.resources.map(r => {
        const [bg,fg] = TYPE_TINT[r.type];
        return (
          <div key={r.title} className="card" style={{ padding: 12, display: 'flex', gap: 12 }}>
            <span style={{ width: 56, height: 56, borderRadius: 8, background: bg, color: fg, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Icon name={TYPE_ICON[r.type]} size={22} /></span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', gap: 4, marginBottom: 3 }}>
                <span className="badge" style={{ height: 18, fontSize: 10, textTransform: 'uppercase' }}>{r.type}</span>
              </div>
              <div style={{ font: '600 13.5px var(--font-sans)', lineHeight: 1.35, marginBottom: 3 }}>{r.title}</div>
              <div className="muted tiny">{r.author} · {r.views.toLocaleString()} views</div>
            </div>
          </div>
        );
      })}
    </div>
    <MobileBottomNav active="resources" />
  </div>
);

const MobileCompose = () => (
  <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--surface)' }}>
    <div style={{ height: 52, borderBottom: '1px solid var(--border-2)', display: 'flex', alignItems: 'center', padding: '0 12px' }}>
      <button className="btn btn-ghost btn-sm">Cancel</button>
      <span style={{ marginLeft: 'auto', font: '600 15px var(--font-sans)' }}>New post</span>
      <button className="btn btn-primary btn-sm" style={{ marginLeft: 'auto', height: 30 }}>Publish</button>
    </div>
    <div style={{ flex: 1, padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <button className="btn btn-secondary btn-sm" style={{ alignSelf: 'flex-start', justifyContent: 'space-between', width: '100%' }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 18, height: 18, borderRadius: 5, background: 'var(--r-prayer-bg)', color: 'var(--r-prayer-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="hand" size={11} /></span>
          Posting in Prayer
        </span>
        <Icon name="chev_d" size={13} />
      </button>
      <input className="input" placeholder="Title" style={{ height: 44, fontSize: 18, fontWeight: 600, border: 0, padding: 0 }} defaultValue="Praying for my mom this Friday" />
      <textarea className="input textarea" style={{ flex: 1, border: 0, padding: 0, fontSize: 15, lineHeight: 1.6 }} placeholder="Share what's on your heart…" />
      <div style={{ display: 'flex', gap: 6, marginTop: 'auto', flexWrap: 'wrap' }}>
        <span className="badge" style={{ background: 'var(--primary-soft)', color: 'var(--primary-2)', border: 0 }}>#prayer <Icon name="x" size={9}/></span>
        <span className="badge" style={{ background: 'var(--primary-soft)', color: 'var(--primary-2)', border: 0 }}>#family <Icon name="x" size={9}/></span>
      </div>
    </div>
    <div style={{ borderTop: '1px solid var(--border-2)', padding: '8px 12px', display: 'flex', gap: 4, color: 'var(--muted)' }}>
      <button className="btn btn-ghost btn-icon btn-sm"><Icon name="image" size={16}/></button>
      <button className="btn btn-ghost btn-icon btn-sm"><Icon name="user" size={16}/></button>
      <button className="btn btn-ghost btn-sm" style={{ fontSize: 12 }}>#tag</button>
      <span style={{ marginLeft: 'auto', fontSize: 11, fontFamily: 'var(--font-mono)', alignSelf: 'center', color: 'var(--muted)' }}>284 / 4000</span>
    </div>
  </div>
);

window.MobileFeed = MobileFeed;
window.MobilePost = MobilePost;
window.MobileRoom = MobileRoom;
window.MobileProfile = MobileProfile;
window.MobileNotifications = MobileNotifications;
window.MobileLibrary = MobileLibrary;
window.MobileCompose = MobileCompose;

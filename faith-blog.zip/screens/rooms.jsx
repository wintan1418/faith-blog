// Rooms index + detail variants

const RoomsIndex = () => (
  <div className="page">
    <TopNav active="rooms" />
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '24px', width: '100%' }}>
      <PageHeader title="Rooms" subtitle="Topic-based spaces inside the community">
        <div style={{ position: 'relative' }}>
          <Icon name="search" size={13} style={{ position: 'absolute', left: 10, top: 9, color: 'var(--muted)' }} />
          <input className="input btn-sm" style={{ paddingLeft: 30, height: 30, width: 200, fontSize: 12.5 }} placeholder="Search rooms" />
        </div>
        <button className="btn btn-secondary btn-sm">All <Icon name="chev_d" size={12} /></button>
      </PageHeader>

      <div style={{ display: 'flex', gap: 6, padding: '14px 0' }}>
        {['All','Joined','Public','Most active'].map((c,i) => <button key={c} className={'chip' + (i===0?' active':'')}>{c}</button>)}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14 }}>
        {SAMPLE.rooms.map(r => (
          <a key={r.name} className="card" style={{ padding: 18, textDecoration: 'none', color: 'inherit', display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ width: 36, height: 36, borderRadius: 10, background: `var(--r-${r.color}-bg)`, color: `var(--r-${r.color}-fg)`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={r.icon} size={18} />
              </span>
              <span className="badge" style={{ background: 'var(--surface-2)' }}><Icon name="globe" size={10} /> Public</span>
            </div>
            <div>
              <div style={{ font: '600 15px var(--font-sans)', marginBottom: 4 }}>{r.name}</div>
              <div className="muted" style={{ fontSize: 13, lineHeight: 1.45 }}>{r.desc}</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid var(--border-2)', paddingTop: 10 }}>
              <span className="muted tiny">{r.members.toLocaleString()} members · {r.posts.toLocaleString()} posts</span>
              <button className="btn btn-secondary btn-sm" style={{ height: 26, fontSize: 12 }}>Join</button>
            </div>
          </a>
        ))}
      </div>
    </div>
  </div>
);

const RoomDetail = () => {
  const r = SAMPLE.rooms[0]; // Prayer
  return (
    <div className="page">
      <TopNav active="rooms" />
      <div style={{ background: `var(--r-${r.color}-bg)`, borderBottom: `1px solid var(--border-2)` }}>
        <div style={{ maxWidth: 1100, margin: '0 auto', padding: '24px', display: 'flex', alignItems: 'flex-start', gap: 18 }}>
          <span style={{ width: 64, height: 64, borderRadius: 14, background: 'var(--surface)', color: `var(--r-${r.color}-fg)`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'var(--sh-sm)' }}>
            <Icon name={r.icon} size={28} />
          </span>
          <div style={{ flex: 1 }}>
            <div className="muted tiny" style={{ marginBottom: 4 }}>Rooms / {r.name}</div>
            <h1 style={{ font: '600 26px var(--font-sans)', letterSpacing: '-0.01em', marginBottom: 6 }}>{r.name}</h1>
            <p style={{ margin: 0, color: `var(--r-${r.color}-fg)`, maxWidth: 640, fontSize: 14 }}>{r.desc}</p>
            <div style={{ display: 'flex', gap: 16, fontSize: 13, color: `var(--r-${r.color}-fg)`, marginTop: 12 }}>
              <span><b>{r.members.toLocaleString()}</b> members</span>
              <span><b>{r.posts.toLocaleString()}</b> posts</span>
              <span><Icon name="globe" size={12} /> Public</span>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary btn-sm">Joined ✓</button>
            <button className="btn btn-primary btn-sm"><Icon name="plus" size={13} /> New post</button>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 24, maxWidth: 1100, margin: '0 auto', padding: '20px 24px', width: '100%' }}>
        <main style={{ minWidth: 0 }}>
          <div className="tabs" style={{ marginBottom: 16 }}>
            {['Posts','Rules','Members'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')}>{t}</div>)}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {SAMPLE.posts.filter(p => p.room === 'Prayer' || p.room === 'Encourage').slice(0,3).map(p => <PostCard key={p.id} post={p} />)}
            {SAMPLE.posts.slice(0,2).map(p => <PostCard key={'x'+p.id} post={p} />)}
          </div>
        </main>
        <aside>
          <div className="card" style={{ padding: 14, marginBottom: 12 }}>
            <div style={{ font: '600 13px var(--font-sans)', marginBottom: 10 }}>House rules</div>
            <ol style={{ margin: 0, paddingLeft: 18, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.6 }}>
              <li>Pray, don't preach.</li>
              <li>Share requests; don't fix.</li>
              <li>Honor anonymity if asked.</li>
              <li>Update us when you can.</li>
            </ol>
          </div>
          <div className="card" style={{ padding: 14 }}>
            <div style={{ font: '600 13px var(--font-sans)', marginBottom: 10 }}>Moderators</div>
            {['Daniel Okafor','Hannah Reyes'].map(n => (
              <div key={n} style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 8 }}>
                <Avatar name={n} size="sm" />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{n}</div>
                  <div className="muted tiny">@{n.toLowerCase().split(' ')[0]}</div>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
};

// Variant: minimalist room (no tinted hero)
const RoomMinimal = () => {
  const r = SAMPLE.rooms[2]; // Bible Study
  return (
    <div className="page">
      <TopNav active="rooms" />
      <div style={{ maxWidth: 720, margin: '0 auto', padding: '32px 24px', width: '100%' }}>
        <a className="muted tiny" style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginBottom: 16 }}><Icon name="chev_l" size={12} /> All rooms</a>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
          <span style={{ width: 32, height: 32, borderRadius: 8, background: `var(--r-${r.color}-bg)`, color: `var(--r-${r.color}-fg)`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={r.icon} size={16} /></span>
          <h1 style={{ font: '600 22px var(--font-sans)' }}>{r.name}</h1>
          <button className="btn btn-secondary btn-sm" style={{ marginLeft: 'auto' }}>Joined ✓</button>
          <button className="btn btn-primary btn-sm"><Icon name="plus" size={13}/></button>
        </div>
        <p className="muted" style={{ marginBottom: 16 }}>{r.desc}</p>
        <div className="muted tiny" style={{ marginBottom: 24 }}>{r.members.toLocaleString()} members · {r.posts.toLocaleString()} posts · Public</div>
        <div className="tabs" style={{ marginBottom: 16 }}>
          {['Posts','Rules','Members'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')}>{t}</div>)}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {SAMPLE.posts.slice(2,5).map(p => <PostCard key={p.id} post={p} />)}
        </div>
      </div>
    </div>
  );
};

window.RoomsIndex = RoomsIndex;
window.RoomDetail = RoomDetail;
window.RoomMinimal = RoomMinimal;

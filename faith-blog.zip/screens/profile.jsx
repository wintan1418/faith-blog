// Profile + brethren card + connections

const ProfileMain = () => (
  <div className="page">
    <TopNav active="" />
    <div style={{ maxWidth: 960, margin: '0 auto', padding: '24px', width: '100%' }}>
      <a className="muted tiny" style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginBottom: 16 }}><Icon name="chev_l" size={12} /> Back</a>
      <header className="card" style={{ padding: 24, display: 'flex', gap: 20, alignItems: 'flex-start', marginBottom: 16 }}>
        <Avatar name="Daniel Okafor" size="xl" />
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <h1 style={{ font: '600 22px var(--font-sans)' }}>Daniel Okafor</h1>
            <span className="badge badge-mod">Moderator</span>
          </div>
          <div className="muted" style={{ marginBottom: 10 }}>@danielo · joined March 2024</div>
          <p style={{ margin: 0, fontSize: 14, color: 'var(--ink-2)', maxWidth: 520, lineHeight: 1.5 }}>Husband, dad, software eng. Posts mostly about grace, fatherhood, and the long obedience.</p>
          <div style={{ display: 'flex', gap: 16, marginTop: 12, fontSize: 13, color: 'var(--muted)' }}>
            <span><Icon name="map_pin" size={12} /> Lagos, Nigeria</span>
            <span><Icon name="cross" size={12} /> Anglican</span>
            <span><Icon name="link" size={12} /> danielo.dev</span>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, minWidth: 180 }}>
          <button className="btn btn-primary btn-sm">+ Follow</button>
          <button className="btn btn-secondary btn-sm">Can I know you more?</button>
          <button className="btn btn-ghost btn-sm">Message</button>
        </div>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 16 }}>
        {[['Posts','127'],['Followers','1,284'],['Following','312']].map(([l,v]) => (
          <div key={l} className="card" style={{ padding: 16, textAlign: 'center' }}>
            <div style={{ font: '600 22px var(--font-display)' }}>{v}</div>
            <div className="muted tiny">{l}</div>
          </div>
        ))}
      </div>

      <div className="tabs" style={{ marginBottom: 14 }}>
        {['Posts','Replies','Reactions','Bookmarks'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')}>{t}</div>)}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {SAMPLE.posts.slice(0,3).map(p => <PostCard key={p.id} post={{...p, author: 'Daniel Okafor'}} />)}
      </div>
    </div>
  </div>
);

const ProfileVisual = () => (
  <div className="page">
    <TopNav />
    <div style={{ height: 140, background: 'linear-gradient(135deg, var(--r-testimony-bg), var(--r-encourage-bg))', borderBottom: '1px solid var(--border-2)' }} />
    <div style={{ maxWidth: 720, margin: '-60px auto 0', padding: '0 24px 24px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16, marginBottom: 16 }}>
        <Avatar name="Imani Abara" size="xl" />
        <div style={{ flex: 1, marginBottom: 8 }}>
          <h1 style={{ font: '500 24px var(--font-display)' }}>Imani Abara</h1>
          <div className="muted">@imani · she/her</div>
        </div>
        <button className="btn btn-primary btn-sm">+ Follow</button>
        <button className="btn btn-secondary btn-sm">Connect</button>
      </div>
      <p className="serif" style={{ fontSize: 17, color: 'var(--ink-2)', marginBottom: 16 }}>"Reading slowly, praying badly, learning to stay."</p>
      <div className="muted tiny" style={{ display: 'flex', gap: 14, marginBottom: 24, paddingBottom: 16, borderBottom: '1px solid var(--border-2)' }}>
        <span><Icon name="map_pin" size={11}/> Nairobi</span>
        <span><Icon name="cross" size={11}/> Reformed</span>
        <span>Joined Sep 2024</span>
        <span style={{ marginLeft: 'auto' }}><b style={{ color: 'var(--ink)' }}>89</b> posts · <b style={{ color: 'var(--ink)' }}>2,104</b> followers</span>
      </div>
      <div className="tabs" style={{ marginBottom: 14 }}>
        {['Posts','Replies','Bookmarks'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')}>{t}</div>)}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {SAMPLE.posts.slice(2,5).map(p => <PostCard key={p.id} post={{...p, author: 'Imani Abara'}} />)}
      </div>
    </div>
  </div>
);

const BrethrenCard = () => (
  <div className="page">
    <TopNav />
    <div style={{ maxWidth: 560, margin: '0 auto', padding: '32px 24px', width: '100%' }}>
      <div className="muted tiny" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 10px', borderRadius: 999, background: 'var(--primary-soft)', color: 'var(--primary-2)', marginBottom: 16 }}>
        <Icon name="lock" size={11} /> Shared with you · Daniel accepted your request
      </div>

      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, padding: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, paddingBottom: 18, borderBottom: '1px solid var(--border-2)', marginBottom: 18 }}>
          <Avatar name="Daniel Okafor" size="lg" />
          <div>
            <div className="muted tiny" style={{ marginBottom: 2 }}>Brethren Card</div>
            <h2 style={{ font: '600 18px var(--font-sans)' }}>Daniel Okafor</h2>
            <div className="muted tiny">@danielo</div>
          </div>
        </div>

        <div style={{ display: 'grid', gap: 14 }}>
          {[
            ['Church / Assembly', 'Christ Church Lagos · Anglican', 'cross'],
            ['Occupation', 'Software engineer at Paystack', 'sparkle'],
            ['Bio', 'Husband to Tola, dad to two. Trying to do small things faithfully.', 'user'],
            ['WhatsApp', '+234 ••• 4729 (revealed below)', 'phone'],
            ['Email', 'daniel.okafor@example.com', 'mail'],
          ].map(([k,v,i]) => (
            <div key={k} style={{ display: 'flex', gap: 12 }}>
              <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--surface-2)', color: 'var(--muted)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Icon name={i} size={14} /></span>
              <div>
                <div className="muted tiny" style={{ marginBottom: 2 }}>{k}</div>
                <div style={{ fontSize: 14 }}>{v}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 20, padding: 12, borderRadius: 8, background: 'var(--surface-2)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <Icon name="shield" size={14} style={{ color: 'var(--muted)', marginTop: 2 }} />
          <div className="muted tiny" style={{ lineHeight: 1.5 }}>This card is private. Daniel chose to share it with you. Please don't forward contact info without asking.</div>
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }}>Open WhatsApp</button>
          <button className="btn btn-secondary btn-sm" style={{ flex: 1 }}>Send email</button>
          <button className="btn btn-ghost btn-icon btn-sm"><Icon name="dots" size={14} /></button>
        </div>
      </div>
    </div>
  </div>
);

const ConnectionsScreen = () => (
  <div className="page">
    <TopNav active="connections" />
    <div style={{ maxWidth: 880, margin: '0 auto', padding: '24px', width: '100%' }}>
      <PageHeader title="Connections" subtitle="People who've shared a Brethren Card with you, and pending requests.">
        <button className="btn btn-secondary btn-sm">Edit my card</button>
      </PageHeader>
      <div className="tabs" style={{ marginTop: 12, marginBottom: 16 }}>
        <div className="tab active">My connections · 18</div>
        <div className="tab">Incoming · 3</div>
        <div className="tab">Sent · 5</div>
      </div>

      <div className="card" style={{ padding: 14, marginBottom: 14, background: 'var(--accent-soft)', border: '1px solid #e1c896' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Icon name="hand" size={16} style={{ color: '#7a5a2c' }} />
          <div style={{ flex: 1, fontSize: 13.5, color: '#5a4a2c' }}>
            <b>3 incoming requests</b> — review carefully. Connections share contact info both ways.
          </div>
          <button className="btn btn-secondary btn-sm">Review</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 12 }}>
        {['Daniel Okafor','Imani Abara','Joseph Adei','Ruth Mwangi','Caleb Stone','Hannah Reyes'].map(n => (
          <div key={n} className="card" style={{ padding: 14, display: 'flex', gap: 12, alignItems: 'center' }}>
            <Avatar name={n} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600 }}>{n}</div>
              <div className="muted tiny">Connected since {['Mar','Apr','May'][n.length%3]} 2025</div>
            </div>
            <button className="btn btn-secondary btn-sm">Open card</button>
          </div>
        ))}
      </div>
    </div>
  </div>
);

window.ProfileMain = ProfileMain;
window.ProfileVisual = ProfileVisual;
window.BrethrenCard = BrethrenCard;
window.ConnectionsScreen = ConnectionsScreen;

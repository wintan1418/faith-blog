// Screens 2: Post detail + composer
const PostDetail = () => {
  const p = SAMPLE.posts[0];
  return (
    <div className="page">
      <TopNav active="feed" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 32, maxWidth: 1100, margin: '0 auto', padding: '24px', width: '100%' }}>
        <main style={{ minWidth: 0 }}>
          <a className="muted tiny" style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginBottom: 16, textDecoration: 'none' }}>
            <Icon name="chev_l" size={12} /> Back to feed
          </a>

          <article style={{ background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--border)', padding: 32 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
              <RoomBadge room={p.room} />
              {p.featured && <span className="badge" style={{ background: 'var(--accent-soft)', color: '#7a5a2c', borderColor: 'transparent' }}><Icon name="pin" size={10} /> Featured</span>}
              <span className="muted tiny">· 4 min read · 1,284 views</span>
            </div>

            <h1 className="display" style={{ fontSize: 36, lineHeight: 1.15, marginBottom: 16 }}>{p.title}</h1>

            <div style={{ display: 'flex', alignItems: 'center', gap: 12, paddingBottom: 20, borderBottom: '1px solid var(--border-2)', marginBottom: 24 }}>
              <Avatar name={p.author} />
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 14, fontWeight: 600 }}>
                  {p.author}
                  <span className="badge badge-mod" style={{ height: 18, fontSize: 10 }}>Moderator</span>
                </div>
                <div className="muted tiny">@danielo · May 3, 2026 · 2 hours ago</div>
              </div>
              <button className="btn btn-secondary btn-sm" style={{ marginLeft: 'auto' }}>+ Follow</button>
              <button className="btn btn-ghost btn-icon btn-sm"><Icon name="dots" size={15} /></button>
            </div>

            <div className="serif" style={{ fontSize: 18, lineHeight: 1.65, color: 'var(--ink)' }}>
              <p style={{ marginTop: 0 }}>For years I thought I had to fix myself before I could come to Him. I'd read a verse, feel convicted, then white-knuckle a week of trying to be better — and quietly drift again.</p>
              <p>Last Sunday I missed my normal bus. The 47 came instead, and I sat across from a woman reading Psalms out loud, very quietly, to herself. She didn't know I was listening.</p>
              <p style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontStyle: 'italic', borderLeft: '3px solid var(--accent)', paddingLeft: 16, margin: '24px 0', color: 'var(--ink-2)' }}>"You hem me in behind and before, and you lay your hand upon me." — Psalm 139</p>
              <p>I'd read that verse a hundred times. That morning it landed like water. Hemmed in. Not abandoned to my own effort. Held while I'm still figuring it out.</p>
              <p>I want to say to anyone here who feels like they're running: stop. Sit down. The grace was already there before you turned around.</p>
            </div>

            <div style={{ borderRadius: 10, overflow: 'hidden', aspectRatio: '16/9', background: 'repeating-linear-gradient(135deg, var(--bg-2), var(--bg-2) 8px, var(--surface-2) 8px, var(--surface-2) 16px)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 12, margin: '24px 0' }}>
              [image · sunrise on city bus]
            </div>

            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 24 }}>
              {p.tags.map(t => <span key={t} className="badge" style={{ background: 'var(--surface-2)' }}>#{t}</span>)}
            </div>

            {/* Reactions */}
            <div style={{ borderTop: '1px solid var(--border-2)', borderBottom: '1px solid var(--border-2)', padding: '20px 0', margin: '28px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
              <ReactionRow counts={{ amen: 47, love: 22, encourage: 12, praying: 8, inspired: 4 }} active="amen" />
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn btn-secondary btn-sm"><Icon name="repost" size={14} /> Reshare · 6</button>
                <button className="btn btn-secondary btn-sm btn-icon"><Icon name="bookmark" size={14} /></button>
                <button className="btn btn-secondary btn-sm btn-icon"><Icon name="share" size={14} /></button>
              </div>
            </div>
          </article>

          {/* Comments */}
          <section style={{ marginTop: 28 }}>
            <h2 style={{ font: '600 16px var(--font-sans)', marginBottom: 14 }}>Comments · 14</h2>
            <div className="card" style={{ padding: 14, display: 'flex', gap: 10, marginBottom: 20 }}>
              <Avatar name="Sarah" size="sm" />
              <div style={{ flex: 1 }}>
                <textarea className="input textarea" placeholder="Add a thoughtful reply. @mention to tag someone." />
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
                  <span className="muted tiny">Mentions and reactions enabled · markdown ok</span>
                  <button className="btn btn-primary btn-sm">Post comment</button>
                </div>
              </div>
            </div>

            {[
              { who: 'Imani Abara', time: '1h', body: 'This is exactly where I was last spring. Thank you for sharing it. The "hemmed in" image will sit with me all week.', rxn: 12, replies: [
                { who: 'Daniel Okafor', time: '52m', body: '@imani thank you — that line wouldn\'t leave me either. Praying you keep noticing it.' }
              ] },
              { who: 'Joseph Adei', time: '1h', body: 'Brother. Sat on a bus last week reading the same chapter. He really does meet us where we are.', rxn: 8, replies: [] },
              { who: 'Anonymous', time: '40m', body: 'Needed this today. Thank you.', rxn: 5, replies: [], anonymous: true },
            ].map((c,i) => (
              <div key={i} style={{ display: 'flex', gap: 10, marginBottom: 18 }}>
                <Avatar name={c.who} size="sm" anonymous={c.anonymous} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                    <span style={{ fontWeight: 600 }}>{c.anonymous ? 'Anonymous' : c.who}</span>
                    <span className="muted">·</span>
                    <span className="muted tiny">{c.time}</span>
                  </div>
                  <div style={{ fontSize: 14, color: 'var(--ink-2)', margin: '4px 0 6px', lineHeight: 1.5 }}>{c.body}</div>
                  <div style={{ display: 'flex', gap: 12, fontSize: 12, color: 'var(--muted)' }}>
                    <button className="btn btn-ghost btn-sm" style={{ height: 24, padding: '0 6px', fontSize: 12 }}>🙏 {c.rxn}</button>
                    <button className="btn btn-ghost btn-sm" style={{ height: 24, padding: '0 6px', fontSize: 12 }}>Reply</button>
                  </div>
                  {c.replies.map((r,j) => (
                    <div key={j} style={{ display: 'flex', gap: 10, marginTop: 12, paddingLeft: 0, borderLeft: '2px solid var(--border-2)', paddingLeft: 12 }}>
                      <Avatar name={r.who} size="sm" />
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                          <span style={{ fontWeight: 600 }}>{r.who}</span><span className="muted tiny">· {r.time}</span>
                        </div>
                        <div style={{ fontSize: 13.5, color: 'var(--ink-2)', marginTop: 3 }}>{r.body}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </section>
        </main>

        <aside style={{ position: 'sticky', top: 80, alignSelf: 'flex-start' }}>
          <div className="card" style={{ padding: 14, marginBottom: 12 }}>
            <div style={{ font: '600 13px var(--font-sans)', marginBottom: 10 }}>About the author</div>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <Avatar name="Daniel" />
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>Daniel Okafor</div>
                <div className="muted tiny">Lagos, NG · joined 2024</div>
              </div>
            </div>
            <p className="muted" style={{ fontSize: 13, margin: '10px 0' }}>Husband, dad, software eng. Posts mostly about grace, fatherhood, and the long obedience.</p>
            <div style={{ display: 'flex', gap: 6 }}>
              <button className="btn btn-secondary btn-sm" style={{ flex: 1 }}>Follow</button>
              <button className="btn btn-secondary btn-sm" style={{ flex: 1 }}>Connect</button>
            </div>
          </div>
          <div className="card" style={{ padding: 14 }}>
            <div style={{ font: '600 13px var(--font-sans)', marginBottom: 10 }}>Related</div>
            {SAMPLE.posts.slice(2,5).map(rp => (
              <div key={rp.id} style={{ paddingTop: 10, borderTop: '1px solid var(--border-2)', marginTop: 10 }}>
                <div className="muted tiny" style={{ marginBottom: 3 }}><RoomBadge room={rp.room} /></div>
                <div style={{ fontSize: 13.5, fontWeight: 500, lineHeight: 1.4 }}>{rp.title}</div>
                <div className="muted tiny" style={{ marginTop: 3 }}>{rp.author} · {rp.comments} comments</div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
};

const PostComposer = () => (
  <div className="page">
    <TopNav active="feed" />
    <div style={{ maxWidth: 760, margin: '0 auto', padding: '24px', width: '100%' }}>
      <PageHeader title="New post" subtitle="Share with the community" breadcrumb="Feed → New post">
        <button className="btn btn-ghost btn-sm">Save draft</button>
        <button className="btn btn-secondary btn-sm">Cancel</button>
        <button className="btn btn-primary btn-sm">Publish</button>
      </PageHeader>

      <div className="card" style={{ padding: 24, marginTop: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div>
          <label style={{ font: '500 12px var(--font-sans)', color: 'var(--muted)', display: 'block', marginBottom: 6 }}>Posting in</label>
          <button className="btn btn-secondary" style={{ justifyContent: 'space-between', width: 240 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 18, height: 18, borderRadius: 5, background: 'var(--r-testimony-bg)', color: 'var(--r-testimony-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="sparkle" size={11} /></span>
              Testimony
            </span>
            <Icon name="chev_d" size={13} />
          </button>
        </div>

        <input className="input" placeholder="Title — what is this about?" style={{ height: 48, fontSize: 20, fontWeight: 600, border: 0, padding: '0 0', background: 'transparent' }} />

        <div style={{ display: 'flex', gap: 6, padding: '8px 0', borderTop: '1px solid var(--border-2)', borderBottom: '1px solid var(--border-2)', color: 'var(--muted)' }}>
          {['B','I','S'].map(c => <button key={c} className="btn btn-ghost btn-sm btn-icon" style={{ fontFamily: 'serif', fontWeight: 700, fontStyle: c==='I'?'italic':'normal', textDecoration: c==='S'?'line-through':'none' }}>{c}</button>)}
          <span style={{ width: 1, background: 'var(--border-2)', margin: '4px 4px' }} />
          <button className="btn btn-ghost btn-sm btn-icon"><Icon name="link" size={14} /></button>
          <button className="btn btn-ghost btn-sm btn-icon"><Icon name="image" size={14} /></button>
          <button className="btn btn-ghost btn-sm" style={{ height: 28, padding: '0 8px', fontSize: 12 }}>"Quote"</button>
          <button className="btn btn-ghost btn-sm" style={{ height: 28, padding: '0 8px', fontSize: 12 }}>• List</button>
          <span style={{ marginLeft: 'auto', fontSize: 11, fontFamily: 'var(--font-mono)' }}>0 / 4000</span>
        </div>

        <textarea className="input textarea" style={{ minHeight: 220, border: 0, padding: 0, fontSize: 15, lineHeight: 1.6, resize: 'vertical' }} placeholder="Write here. You can @mention, paste links, drop images — and use markdown if you prefer." />

        <div style={{ borderTop: '1px solid var(--border-2)', paddingTop: 16 }}>
          <label style={{ font: '500 12px var(--font-sans)', color: 'var(--muted)', display: 'block', marginBottom: 6 }}>Images <span style={{ fontWeight: 400 }}>· up to 5</span></label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8 }}>
            {[0,1].map(i => (
              <div key={i} style={{ aspectRatio: '1/1', borderRadius: 8, background: 'repeating-linear-gradient(135deg, var(--bg-2), var(--bg-2) 6px, var(--surface-2) 6px, var(--surface-2) 12px)', position: 'relative' }}>
                <button className="btn btn-secondary btn-sm btn-icon" style={{ position: 'absolute', top: 4, right: 4, width: 22, height: 22, borderRadius: 999 }}><Icon name="x" size={11}/></button>
              </div>
            ))}
            <button style={{ aspectRatio: '1/1', borderRadius: 8, border: '1.5px dashed var(--border)', background: 'transparent', color: 'var(--muted)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, fontSize: 12, cursor: 'pointer' }}>
              <Icon name="plus" size={14} /> Add
            </button>
          </div>
        </div>

        <div>
          <label style={{ font: '500 12px var(--font-sans)', color: 'var(--muted)', display: 'block', marginBottom: 6 }}>Tags</label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, padding: 6, borderRadius: 8, border: '1px solid var(--border)', background: 'var(--surface)', minHeight: 36 }}>
            {['testimony','grace'].map(t => <span key={t} className="badge" style={{ background: 'var(--primary-soft)', color: 'var(--primary-2)', borderColor: 'transparent' }}>#{t} <Icon name="x" size={10}/></span>)}
            <input style={{ flex: 1, minWidth: 100, border: 0, outline: 0, background: 'transparent', fontSize: 13 }} placeholder="Add tag…" />
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: 14, borderRadius: 10, background: 'var(--surface-2)' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13.5 }}>
            <input type="checkbox" /> Post anonymously <span className="muted tiny">— your name will be hidden</span>
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13.5 }}>
            <input type="checkbox" defaultChecked /> Allow comments
          </label>
        </div>
      </div>
    </div>
  </div>
);

window.PostDetail = PostDetail;
window.PostComposer = PostComposer;

// Resources, search, notifications, bookmarks, settings, auth, landing, admin

const TYPE_ICON = { pdf: 'pdf', video: 'video', book: 'book', audio: 'audio', link: 'link' };
const TYPE_TINT = { pdf: ['#f1d7c8','#7a3a26'], video: ['#dde7e8','#3e5d63'], book: ['#dde7d8','#2f5a45'], audio: ['#e8dde6','#6a4a64'], link: ['#efe2c4','#7a5a2c'] };

const Resources = () => (
  <div className="page">
    <TopNav active="resources" />
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '24px', width: '100%' }}>
      <PageHeader title="Library" subtitle="Articles, videos, audio, books, and PDFs — submitted by members and approved.">
        <div style={{ position: 'relative' }}>
          <Icon name="search" size={13} style={{ position: 'absolute', left: 10, top: 9, color: 'var(--muted)' }} />
          <input className="input" style={{ paddingLeft: 30, height: 30, width: 220, fontSize: 12.5 }} placeholder="Search library" />
        </div>
        <button className="btn btn-primary btn-sm"><Icon name="upload" size={13} /> Submit</button>
      </PageHeader>
      <div style={{ display: 'flex', gap: 6, padding: '14px 0', flexWrap: 'wrap' }}>
        {['All types','PDF','Video','Audio','Book','Link'].map((c,i) => <button key={c} className={'chip' + (i===0?' active':'')}>{c}</button>)}
        <span style={{ width: 1, background: 'var(--border-2)', margin: '0 4px' }} />
        {['Prayer','Bible Study','Theology','Devotional'].map(c => <button key={c} className="chip">{c}</button>)}
      </div>

      <section style={{ marginTop: 8, marginBottom: 24 }}>
        <h3 style={{ font: '600 14px var(--font-sans)', marginBottom: 10 }}>Featured</h3>
        <div className="card" style={{ padding: 0, overflow: 'hidden', display: 'grid', gridTemplateColumns: '280px 1fr' }}>
          <div style={{ aspectRatio: '4/3', background: 'repeating-linear-gradient(135deg, var(--bg-2), var(--bg-2) 8px, var(--surface-2) 8px, var(--surface-2) 16px)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 11 }}>[cover · psalms guide]</div>
          <div style={{ padding: 20 }}>
            <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
              <span className="badge" style={{ background: 'var(--r-prayer-bg)', color: 'var(--r-prayer-fg)', border: 0 }}><Icon name="pdf" size={11}/> PDF</span>
              <span className="badge"><Icon name="pin" size={10}/> Featured</span>
            </div>
            <h2 className="display" style={{ fontSize: 24, marginBottom: 6 }}>Praying with the Psalms — a 30 day guide</h2>
            <p className="muted" style={{ fontSize: 13.5, marginBottom: 12 }}>A daily practice for praying through the Psalter, paced for busy seasons. Includes a printable booklet.</p>
            <div className="muted tiny" style={{ marginBottom: 14 }}>By Eugene H. · 24 pages · 1,284 downloads</div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-primary btn-sm"><Icon name="download" size={13} /> Download</button>
              <button className="btn btn-secondary btn-sm"><Icon name="bookmark" size={13} /> Save</button>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <h3 style={{ font: '600 14px var(--font-sans)' }}>Recent</h3>
          <a className="muted tiny">See all →</a>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12 }}>
          {SAMPLE.resources.map(r => {
            const [bg, fg] = TYPE_TINT[r.type];
            return (
              <a key={r.title} className="card" style={{ padding: 14, textDecoration: 'none', color: 'inherit', display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div style={{ aspectRatio: '16/10', borderRadius: 8, background: bg, color: fg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name={TYPE_ICON[r.type]} size={28} />
                </div>
                <div>
                  <div style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
                    <span className="badge" style={{ background: bg, color: fg, border: 0, textTransform: 'uppercase', fontSize: 10 }}>{r.type}</span>
                    <span className="badge">{r.cat}</span>
                  </div>
                  <div style={{ font: '600 14px var(--font-sans)', lineHeight: 1.35, marginBottom: 4 }}>{r.title}</div>
                  <div className="muted tiny">{r.author} · {r.views.toLocaleString()} views</div>
                </div>
              </a>
            );
          })}
        </div>
      </section>
    </div>
  </div>
);

const SearchScreen = () => (
  <div className="page">
    <TopNav />
    <div style={{ maxWidth: 880, margin: '0 auto', padding: '24px', width: '100%' }}>
      <div style={{ position: 'relative', marginBottom: 16 }}>
        <Icon name="search" size={18} style={{ position: 'absolute', left: 16, top: 14, color: 'var(--muted)' }} />
        <input className="input" autoFocus defaultValue="prayer" style={{ height: 48, paddingLeft: 44, fontSize: 16 }} />
      </div>
      <div className="muted tiny" style={{ marginBottom: 12 }}>About 247 results for "prayer"</div>
      <div className="tabs" style={{ marginBottom: 16 }}>
        <div className="tab active">Posts · 142</div>
        <div className="tab">People · 38</div>
        <div className="tab">Resources · 67</div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {SAMPLE.posts.filter(p => p.tags && p.tags.includes('prayer')).slice(0,3).map(p => <PostCard key={p.id} post={p} />)}
        {SAMPLE.posts.slice(0,2).map(p => <PostCard key={'s'+p.id} post={p} />)}
      </div>
    </div>
  </div>
);

const Notifications = () => (
  <div className="page">
    <TopNav />
    <div style={{ maxWidth: 720, margin: '0 auto', padding: '24px', width: '100%' }}>
      <PageHeader title="Notifications" subtitle="3 unread">
        <button className="btn btn-ghost btn-sm">Mark all read</button>
        <button className="btn btn-secondary btn-sm">Settings</button>
      </PageHeader>
      <div className="tabs" style={{ marginTop: 12, marginBottom: 12 }}>
        {['All','Mentions','Connections','System'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')}>{t}</div>)}
      </div>
      <div className="card" style={{ overflow: 'hidden' }}>
        {SAMPLE.notifications.map((n,i) => {
          const ICONS = { reply: 'chat', mention: 'sparkle', connect: 'users', react: 'heart', follow: 'user', feature: 'pin', resource: 'book' };
          return (
            <div key={i} style={{ display: 'flex', gap: 12, padding: 14, borderBottom: i < SAMPLE.notifications.length-1 ? '1px solid var(--border-2)' : 0, background: n.unread ? 'var(--surface-2)' : 'transparent', position: 'relative' }}>
              {n.unread && <span style={{ position: 'absolute', left: 6, top: 24, width: 6, height: 6, borderRadius: 999, background: 'var(--accent)' }} />}
              <Avatar name={n.actor} size="sm" />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13.5 }}><b>{n.actor}</b> {n.text}</div>
                <div className="muted tiny" style={{ marginTop: 2, display: 'inline-flex', alignItems: 'center', gap: 5 }}><Icon name={ICONS[n.type]} size={11} /> {n.time} ago</div>
              </div>
              {n.type === 'connect' && <div style={{ display: 'flex', gap: 6 }}><button className="btn btn-secondary btn-sm" style={{ height: 26 }}>Decline</button><button className="btn btn-primary btn-sm" style={{ height: 26 }}>Accept</button></div>}
            </div>
          );
        })}
      </div>
    </div>
  </div>
);

const Bookmarks = () => (
  <div className="page">
    <TopNav />
    <div style={{ maxWidth: 720, margin: '0 auto', padding: '24px', width: '100%' }}>
      <PageHeader title="Bookmarks" subtitle="Posts you've saved to read again">
        <button className="btn btn-secondary btn-sm">All <Icon name="chev_d" size={12} /></button>
      </PageHeader>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 16 }}>
        {SAMPLE.posts.slice(0,3).map(p => <PostCard key={p.id} post={p} />)}
      </div>
    </div>
  </div>
);

const Settings = () => (
  <div className="page">
    <TopNav />
    <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: 24, maxWidth: 1000, margin: '0 auto', padding: '24px', width: '100%' }}>
      <aside>
        <div className="muted tiny" style={{ textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8, fontFamily: 'var(--font-mono)' }}>Settings</div>
        {['Profile','Account','Brethren Card','Notifications','Privacy','Sessions'].map((s,i) => (
          <a key={s} style={{ display: 'block', padding: '8px 10px', borderRadius: 7, fontSize: 13.5, color: i===0 ? 'var(--ink)' : 'var(--ink-2)', background: i===0 ? 'var(--surface-2)' : 'transparent', fontWeight: i===0?600:500 }}>{s}</a>
        ))}
      </aside>
      <main>
        <h1 style={{ font: '600 20px var(--font-sans)', marginBottom: 4 }}>Profile</h1>
        <p className="muted" style={{ marginBottom: 24 }}>Visible to anyone in the community unless your profile is private.</p>
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, paddingBottom: 18, borderBottom: '1px solid var(--border-2)', marginBottom: 18 }}>
            <Avatar name="Sarah Mensah" size="xl" />
            <div>
              <button className="btn btn-secondary btn-sm">Upload new</button>
              <div className="muted tiny" style={{ marginTop: 6 }}>JPG/PNG · max 2MB</div>
            </div>
          </div>
          {[
            ['Display name', 'Sarah Mensah'],
            ['Username', '@sarah.m', true],
            ['Bio', "Writer, slow reader, learning to listen.", true, 'textarea'],
            ['Location', 'Accra, Ghana'],
            ['Faith background', 'Pentecostal'],
            ['Website', 'sarahmensah.co'],
          ].map(([l,v,_,kind]) => (
            <div key={l} style={{ display: 'grid', gridTemplateColumns: '180px 1fr', gap: 16, padding: '12px 0', borderBottom: '1px solid var(--border-2)' }}>
              <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--ink-2)', paddingTop: 8 }}>{l}</label>
              {kind === 'textarea' ? <textarea className="input textarea" defaultValue={v} /> : <input className="input" defaultValue={v} />}
            </div>
          ))}
          <div style={{ display: 'grid', gridTemplateColumns: '180px 1fr', gap: 16, padding: '16px 0', alignItems: 'center' }}>
            <label style={{ fontSize: 13, fontWeight: 500 }}>Public profile</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ width: 36, height: 22, borderRadius: 999, background: 'var(--primary)', position: 'relative' }}>
                <span style={{ position: 'absolute', right: 2, top: 2, width: 18, height: 18, borderRadius: 999, background: 'white' }} />
              </span>
              <span className="muted tiny">Anyone can see your profile and posts</span>
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 16 }}>
            <button className="btn btn-ghost btn-sm">Cancel</button>
            <button className="btn btn-primary btn-sm">Save changes</button>
          </div>
        </div>
      </main>
    </div>
  </div>
);

const SignIn = () => (
  <div style={{ minHeight: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', background: 'var(--bg)' }}>
    <div style={{ background: 'var(--primary)', color: 'var(--surface)', padding: 48, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(255,255,255,0.15)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="cross" size={16} stroke={2} /></span>
        <span style={{ font: '500 18px var(--font-display)' }}>Faith Community</span>
      </div>
      <div>
        <p className="display" style={{ fontSize: 32, lineHeight: 1.2, marginBottom: 16, color: 'rgba(255,255,255,0.95)', fontStyle: 'italic' }}>"As iron sharpens iron, so one person sharpens another."</p>
        <p style={{ opacity: 0.7, fontSize: 13 }}>Proverbs 27:17</p>
      </div>
      <div style={{ opacity: 0.6, fontSize: 12 }}>© 2026 Faith Community</div>
    </div>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 48 }}>
      <div style={{ width: 360 }}>
        <h1 style={{ font: '600 22px var(--font-sans)', marginBottom: 4 }}>Welcome back</h1>
        <p className="muted" style={{ marginBottom: 24 }}>Sign in to continue.</p>
        <label className="muted tiny" style={{ display: 'block', marginBottom: 4 }}>Email</label>
        <input className="input" defaultValue="sarah@example.com" style={{ marginBottom: 12 }} />
        <label className="muted tiny" style={{ display: 'block', marginBottom: 4 }}>Password</label>
        <input className="input" type="password" defaultValue="••••••••" style={{ marginBottom: 12 }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <label style={{ fontSize: 13, display: 'inline-flex', alignItems: 'center', gap: 6 }}><input type="checkbox" defaultChecked /> Remember me</label>
          <a className="tiny" style={{ color: 'var(--primary)' }}>Forgot password?</a>
        </div>
        <button className="btn btn-primary btn-lg" style={{ width: '100%', marginBottom: 12 }}>Sign in</button>
        <div className="muted tiny" style={{ textAlign: 'center' }}>New here? <a style={{ color: 'var(--primary)' }}>Create an account</a></div>
      </div>
    </div>
  </div>
);

const Landing = () => (
  <div style={{ background: 'var(--bg)', minHeight: '100%' }} className="bg-linen">
    <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px 32px', maxWidth: 1200, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ width: 30, height: 30, borderRadius: 8, background: 'var(--primary)', color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="cross" size={14} stroke={2}/></span>
        <span style={{ font: '500 18px var(--font-display)' }}>Faith Community</span>
      </div>
      <nav style={{ display: 'flex', gap: 24, fontSize: 13.5 }}>
        {['Rooms','Library','About','Guidelines'].map(l => <a key={l} className="muted">{l}</a>)}
      </nav>
      <div style={{ display: 'flex', gap: 8 }}>
        <button className="btn btn-ghost btn-sm">Sign in</button>
        <button className="btn btn-primary btn-sm">Join</button>
      </div>
    </header>
    <section style={{ maxWidth: 920, margin: '0 auto', padding: '64px 32px 48px', textAlign: 'center' }}>
      <span className="badge" style={{ marginBottom: 20 }}><Icon name="leaf" size={11} /> A quieter place online</span>
      <h1 className="display" style={{ fontSize: 64, lineHeight: 1.05, marginBottom: 20, letterSpacing: '-0.025em' }}>A community for the<br/><em style={{ color: 'var(--primary)' }}>long obedience</em>.</h1>
      <p className="serif" style={{ fontSize: 19, color: 'var(--ink-2)', maxWidth: 560, margin: '0 auto 28px', lineHeight: 1.5 }}>Faith Community is a space for testimonies, prayer requests, real questions, and small encouragements. Slow social. No outrage feed.</p>
      <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
        <button className="btn btn-primary btn-lg">Join the community</button>
        <button className="btn btn-secondary btn-lg">Explore rooms</button>
      </div>
    </section>
    <section style={{ maxWidth: 1100, margin: '0 auto', padding: '32px 32px 64px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }}>
        {SAMPLE.rooms.slice(0,3).map(r => (
          <div key={r.name} className="card" style={{ padding: 20 }}>
            <span style={{ width: 36, height: 36, borderRadius: 10, background: `var(--r-${r.color}-bg)`, color: `var(--r-${r.color}-fg)`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}><Icon name={r.icon} size={18} /></span>
            <div style={{ font: '600 16px var(--font-sans)', marginBottom: 4 }}>{r.name}</div>
            <p className="muted" style={{ fontSize: 13.5 }}>{r.desc}</p>
            <div className="muted tiny" style={{ marginTop: 10 }}>{r.members.toLocaleString()} members</div>
          </div>
        ))}
      </div>
    </section>
  </div>
);

const AdminDashboard = () => (
  <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', minHeight: '100%', background: 'var(--bg)' }}>
    <aside style={{ background: 'var(--ink)', color: '#bcccc0', padding: '20px 12px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 8px 16px', color: 'white' }}>
        <span style={{ width: 24, height: 24, borderRadius: 6, background: 'var(--primary)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="shield" size={13} stroke={2}/></span>
        <span style={{ font: '600 14px var(--font-sans)' }}>Admin</span>
      </div>
      {[
        ['Dashboard','grid', true],
        ['Users','users'],
        ['Rooms','rooms'],
        ['Posts','feed'],
        ['Resources','book'],
        ['Reports','flag','5'],
        ['Moderation logs','clock'],
      ].map(([l,i,a,n]) => (
        <a key={l} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 7, fontSize: 13, marginBottom: 1, color: a ? 'white' : '#9aab9d', background: a ? 'rgba(255,255,255,0.08)' : 'transparent', fontWeight: a ? 600 : 500 }}>
          <Icon name={i} size={14} /> {l}
          {n && <span style={{ marginLeft: 'auto', background: 'var(--accent)', color: 'var(--ink)', borderRadius: 999, fontSize: 10, padding: '1px 6px', fontWeight: 700 }}>{n}</span>}
        </a>
      ))}
    </aside>
    <main style={{ padding: 24 }}>
      <PageHeader title="Dashboard" subtitle="Health and recent activity">
        <button className="btn btn-secondary btn-sm">Last 7 days <Icon name="chev_d" size={12}/></button>
      </PageHeader>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, margin: '16px 0' }}>
        {[
          ['Total members', '12,847','+128 this week'],
          ['Posts today', '142','steady'],
          ['Pending reports', '5','needs review', true],
          ['Pending resources', '3','needs review', true],
        ].map(([l,v,h,warn]) => (
          <div key={l} className="card" style={{ padding: 16 }}>
            <div className="muted tiny" style={{ marginBottom: 4 }}>{l}</div>
            <div style={{ font: '600 24px var(--font-display)' }}>{v}</div>
            <div className="tiny" style={{ color: warn ? 'var(--accent)' : 'var(--muted)', marginTop: 4 }}>{h}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-2)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ font: '600 13px var(--font-sans)' }}>Pending resources</span>
            <a className="muted tiny">View all</a>
          </div>
          {SAMPLE.resources.slice(0,4).map((r,i) => (
            <div key={r.title} style={{ padding: '12px 16px', borderBottom: i<3 ? '1px solid var(--border-2)' : 0, display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ width: 28, height: 28, borderRadius: 6, background: TYPE_TINT[r.type][0], color: TYPE_TINT[r.type][1], display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={TYPE_ICON[r.type]} size={13}/></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>{r.title}</div>
                <div className="muted tiny">{r.author} · submitted 2h ago</div>
              </div>
              <button className="btn btn-secondary btn-sm" style={{ height: 26 }}>Review</button>
              <button className="btn btn-primary btn-sm" style={{ height: 26 }}>Approve</button>
            </div>
          ))}
        </div>

        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-2)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ font: '600 13px var(--font-sans)' }}>Recent reports</span>
            <a className="muted tiny">View all</a>
          </div>
          {[
            ['Off-topic in Prayer','Joseph A.','2h'],
            ['Spam link in comment','Auto','3h'],
            ['Mean tone reported','Ruth M.','5h'],
          ].map(([t,r,tm],i) => (
            <div key={i} style={{ padding: '12px 16px', borderBottom: i<2 ? '1px solid var(--border-2)' : 0, display: 'flex', alignItems: 'center', gap: 10 }}>
              <Icon name="flag" size={14} style={{ color: 'var(--danger)'}} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{t}</div>
                <div className="muted tiny">Reported by {r} · {tm} ago</div>
              </div>
              <button className="btn btn-secondary btn-sm" style={{ height: 26 }}>Open</button>
            </div>
          ))}
        </div>
      </div>

      <div className="card" style={{ marginTop: 16, padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-2)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ font: '600 13px var(--font-sans)' }}>Recent users</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <input className="input" placeholder="Search users" style={{ height: 28, fontSize: 12, width: 180 }} />
            <button className="btn btn-secondary btn-sm">Export</button>
          </div>
        </div>
        <table style={{ width: '100%', fontSize: 13, borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--surface-2)' }}>
              {['User','Role','Joined','Posts','Status',''].map(h => <th key={h} style={{ textAlign: 'left', padding: '8px 14px', font: '500 11px var(--font-mono)', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {[
              ['Sarah Mensah','member','May 1','127','active'],
              ['Daniel Okafor','moderator','Mar 12','89','active'],
              ['Anonymous user 4827','member','Apr 28','3','pending'],
              ['Imani Abara','member','Sep 14','56','active'],
              ['Reported user','member','Jan 2','12','suspended'],
            ].map((row,i) => (
              <tr key={i} style={{ borderTop: '1px solid var(--border-2)' }}>
                <td style={{ padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 8 }}><Avatar name={row[0]} size="sm" /> {row[0]}</td>
                <td style={{ padding: '10px 14px' }}>{row[1] === 'moderator' ? <span className="badge badge-mod">Moderator</span> : <span className="muted tiny">Member</span>}</td>
                <td style={{ padding: '10px 14px' }} className="muted">{row[2]}</td>
                <td style={{ padding: '10px 14px' }}>{row[3]}</td>
                <td style={{ padding: '10px 14px' }}>
                  <span className="badge" style={{ background: row[4]==='active'?'var(--primary-soft)':row[4]==='suspended'?'#f3d6ce':'var(--surface-2)', color: row[4]==='suspended'?'var(--danger)':row[4]==='active'?'var(--primary-2)':'var(--muted)', border: 0 }}>{row[4]}</span>
                </td>
                <td style={{ padding: '10px 14px', textAlign: 'right' }}><button className="btn btn-ghost btn-icon btn-sm"><Icon name="dots" size={14} /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  </div>
);

window.Resources = Resources;
window.SearchScreen = SearchScreen;
window.Notifications = Notifications;
window.Bookmarks = Bookmarks;
window.Settings = Settings;
window.SignIn = SignIn;
window.Landing = Landing;
window.AdminDashboard = AdminDashboard;

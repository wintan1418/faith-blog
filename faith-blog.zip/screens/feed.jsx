// Screens 1: Feed variants, Post detail, Composer
const { useState: uS1 } = React;

// FEED — Variant A: Classic 3-col with sidebar
const FeedClassic = () => {
  const tabs = ['Recent', 'Trending', 'Following'];
  const [tab, setTab] = uS1('Recent');
  return (
    <div className="page">
      <TopNav active="feed" />
      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr 280px', gap: 24, padding: '24px', maxWidth: 1280, margin: '0 auto', width: '100%' }}>
        <aside>
          <div style={{ font: '500 11px var(--font-mono)', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Your space</div>
          <nav style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            {[
              ['feed','Feed','feed', true],
              ['bookmark','Bookmarks','bookmark'],
              ['user','Profile','user'],
              ['users','Connections','users'],
              ['bell','Notifications','bell','3'],
            ].map(([k,l,i,active,n]) => (
              <a key={k} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '7px 10px', borderRadius: 7, color: active ? 'var(--ink)' : 'var(--ink-2)', background: active ? 'var(--surface-2)' : 'transparent', fontSize: 13.5, fontWeight: active ? 600 : 500, textDecoration: 'none' }}>
                <Icon name={i} size={15} /> {l}
                {n && <span style={{ marginLeft: 'auto', background: 'var(--accent)', color: 'var(--surface)', borderRadius: 999, fontSize: 10, padding: '1px 6px', fontWeight: 600 }}>{n}</span>}
              </a>
            ))}
          </nav>
          <div style={{ font: '500 11px var(--font-mono)', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.06em', margin: '20px 0 8px' }}>Your rooms</div>
          <nav style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            {SAMPLE.rooms.slice(0,5).map(r => (
              <a key={r.name} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '7px 10px', borderRadius: 7, color: 'var(--ink-2)', fontSize: 13.5, textDecoration: 'none' }}>
                <span style={{ width: 18, height: 18, borderRadius: 5, background: `var(--r-${r.color}-bg)`, color: `var(--r-${r.color}-fg)`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name={r.icon} size={11} />
                </span>
                {r.name}
              </a>
            ))}
            <a style={{ padding: '7px 10px', fontSize: 12.5, color: 'var(--muted)' }}>Browse all rooms →</a>
          </nav>
        </aside>

        <main style={{ minWidth: 0 }}>
          {/* Composer entry */}
          <div className="card" style={{ padding: 12, display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
            <Avatar name={SAMPLE.user.name} size="sm" />
            <input className="input" placeholder="Share an encouragement, request, or question…" style={{ background: 'var(--bg)', borderColor: 'transparent' }} />
            <button className="btn btn-ghost btn-icon btn-sm" title="Add image"><Icon name="image" size={15} /></button>
            <button className="btn btn-primary btn-sm">Post</button>
          </div>

          {/* Tabs + filter */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, borderBottom: '1px solid var(--border-2)' }}>
            <div className="tabs" style={{ borderBottom: 0 }}>
              {tabs.map(t => <div key={t} className={'tab' + (tab===t?' active':'')} onClick={()=>setTab(t)}>{t}</div>)}
            </div>
            <div style={{ display: 'flex', gap: 6, padding: '0 0 6px' }}>
              <button className="chip">All rooms <Icon name="chev_d" size={12} /></button>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {SAMPLE.posts.map(p => <PostCard key={p.id} post={p} />)}
          </div>
        </main>

        <aside>
          <div className="card" style={{ padding: 14, marginBottom: 12 }}>
            <div style={{ font: '600 13px var(--font-sans)', marginBottom: 10 }}>Today's verse</div>
            <p className="serif" style={{ margin: 0, fontSize: 18, lineHeight: 1.4, color: 'var(--ink)' }}>"He gives strength to the weary, and increases the power of the weak."</p>
            <div className="muted tiny" style={{ marginTop: 8 }}>Isaiah 40:29 · NIV</div>
          </div>
          <div className="card" style={{ padding: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <span style={{ font: '600 13px var(--font-sans)' }}>Open prayer requests</span>
              <span className="muted tiny">3</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['Joy', '3d before chemo', 'praying'],
                ['Anonymous', 'biopsy results Friday', 'standing'],
                ['Marcus', 'job interview Tue', 'praying'],
              ].map(([n,t,s]) => (
                <div key={n} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                  <Avatar name={n} size="sm" anonymous={n==='Anonymous'} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{n}</div>
                    <div className="muted tiny">{t}</div>
                  </div>
                  <button className="btn btn-secondary btn-sm" style={{ height: 26, fontSize: 12 }}>🙏 Pray</button>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

// FEED — Variant B: Single-column, editorial feel
const FeedEditorial = () => (
  <div className="page bg-linen">
    <TopNav active="feed" />
    <div style={{ maxWidth: 720, margin: '0 auto', padding: '32px 24px', width: '100%' }}>
      <div style={{ marginBottom: 24 }}>
        <h1 className="display" style={{ fontSize: 36, marginBottom: 4 }}>Today in the community</h1>
        <div className="muted">Sunday, May 3 · 142 new posts since you last checked</div>
      </div>
      <div className="card" style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
        <Avatar name="Sarah" size="sm" />
        <input className="input" placeholder="What is on your heart today?" style={{ background: 'transparent', border: 0 }} />
        <button className="btn btn-primary btn-sm">Share</button>
      </div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 20 }}>
        {['Recent','Trending','Following'].map((t,i) => <button key={t} className={'chip' + (i===0?' active':'')}>{t}</button>)}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {SAMPLE.posts.slice(0,4).map(p => <PostCard key={p.id} post={p} />)}
      </div>
    </div>
  </div>
);

// FEED — Variant C: Compact / Twitter-density list
const FeedCompact = () => (
  <div className="page">
    <TopNav active="feed" />
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24, padding: '24px', maxWidth: 1080, margin: '0 auto', width: '100%' }}>
      <main style={{ minWidth: 0 }}>
        <PageHeader title="Feed" subtitle="142 new posts">
          <button className="btn btn-secondary btn-sm"><Icon name="filter" size={13} /> Filter</button>
          <button className="btn btn-primary btn-sm"><Icon name="plus" size={14} /> New post</button>
        </PageHeader>
        <div className="tabs" style={{ marginTop: 12, marginBottom: 4 }}>
          {['Recent','Trending','Following'].map((t,i) => <div key={t} className={'tab' + (i===0?' active':'')}>{t}</div>)}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', borderRadius: 12, border: '1px solid var(--border-2)', background: 'var(--surface)', overflow: 'hidden' }}>
          {SAMPLE.posts.map((p, i) => (
            <div key={p.id} style={{ display: 'flex', gap: 12, padding: 14, borderBottom: i < SAMPLE.posts.length-1 ? '1px solid var(--border-2)' : 0 }}>
              <Avatar name={p.author} size="sm" anonymous={p.anonymous} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5, marginBottom: 3 }}>
                  <span style={{ fontWeight: 600 }}>{p.anonymous ? 'Anonymous' : p.author}</span>
                  <RoomBadge room={p.room} />
                  <span className="muted">·</span><span className="muted">{p.time}</span>
                </div>
                <div style={{ font: '600 14.5px var(--font-sans)', marginBottom: 3 }}>{p.title}</div>
                <div className="muted" style={{ fontSize: 13, marginBottom: 6, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{p.excerpt}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, color: 'var(--muted)', fontSize: 12 }}>
                  <ReactionSummary counts={p.reactions} total={p.reactionTotal} />
                  <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}><Icon name="chat" size={12}/> {p.comments}</span>
                  <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}><Icon name="repost" size={12}/> {p.reshares || 0}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
      <aside style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div className="card" style={{ padding: 14 }}>
          <div style={{ font: '600 13px var(--font-sans)', marginBottom: 10 }}>This week's reading plan</div>
          <p className="muted" style={{ fontSize: 13, marginTop: 0 }}>Day 4 of 7 — The Sermon on the Mount</p>
          <div style={{ height: 6, borderRadius: 999, background: 'var(--surface-2)', marginBottom: 10 }}>
            <div style={{ width: '57%', height: '100%', borderRadius: 999, background: 'var(--primary)' }} />
          </div>
          <button className="btn btn-secondary btn-sm" style={{ width: '100%' }}>Open reading plan</button>
        </div>
      </aside>
    </div>
  </div>
);

window.FeedClassic = FeedClassic;
window.FeedEditorial = FeedEditorial;
window.FeedCompact = FeedCompact;

// Faith Community — shared UI primitives
// Loaded as text/babel; exports to window for use across screens.

const { useState, useEffect, useRef, createContext, useContext } = React;

// ─── Icons ────────────────────────────────────────────────────────
const Icon = ({ name, size = 16, stroke = 1.6, style }) => {
  const paths = {
    home: 'M3 11.5 12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z',
    feed: 'M4 6h16M4 12h16M4 18h10',
    rooms: 'M3 6.5 12 3l9 3.5v11L12 21 3 17.5zM12 3v18M3 6.5 12 10l9-3.5',
    book: 'M4 4h7a3 3 0 0 1 3 3v13M20 4h-7a3 3 0 0 0-3 3v13M4 4v15h6M20 4v15h-6',
    search: 'M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16zm5.5-2.5L21 21',
    bell: 'M6 16V11a6 6 0 1 1 12 0v5l1.5 2H4.5zM10 21a2 2 0 0 0 4 0',
    bookmark: 'M6 4h12v17l-6-4-6 4z',
    user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
    users: 'M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zm8 0a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM2 20a7 7 0 0 1 14 0M16 14a6 6 0 0 1 6 6',
    settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2-1.2L14 3h-4l-.6 2.6a7 7 0 0 0-2 1.2l-2.3-.9-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-.9a7 7 0 0 0 2 1.2L10 21h4l.6-2.6a7 7 0 0 0 2-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z',
    plus: 'M12 5v14M5 12h14',
    chat: 'M21 12a8 8 0 0 1-11.5 7.2L4 21l1.8-5.5A8 8 0 1 1 21 12z',
    repost: 'M7 7h11v4l4-5-4-5v4H5v6M17 17H6v-4l-4 5 4 5v-4h13v-6',
    share: 'M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M16 6l-4-4-4 4M12 2v14',
    heart: 'M12 21s-8-5-8-11a5 5 0 0 1 9-3 5 5 0 0 1 9 3c0 6-8 11-8 11h-2z',
    check: 'M5 12l4 4 10-10',
    x: 'M5 5l14 14M19 5L5 19',
    chev_d: 'M6 9l6 6 6-6',
    chev_r: 'M9 6l6 6-6 6',
    chev_l: 'M15 6l-6 6 6 6',
    arrow_r: 'M5 12h14M13 5l7 7-7 7',
    image: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4',
    link: 'M10 14a4 4 0 0 0 5.6 0l3-3a4 4 0 1 0-5.6-5.6l-1.4 1.4M14 10a4 4 0 0 0-5.6 0l-3 3a4 4 0 1 0 5.6 5.6l1.4-1.4',
    play: 'M7 4v16l13-8z',
    pdf: 'M7 3h7l5 5v13H7zM14 3v5h5',
    video: 'M3 6h12v12H3zM21 8l-6 4 6 4z',
    audio: 'M9 18V5l11-2v13M9 18a3 3 0 1 1-3-3M20 16a3 3 0 1 1-3-3',
    pin: 'M12 21v-7M5 9l3-3 4 4 4-4 3 3-7 7z',
    sparkle: 'M12 3v6M12 15v6M3 12h6M15 12h6M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3',
    hand: 'M9 11V5a2 2 0 0 1 4 0v6M13 11V4a2 2 0 0 1 4 0v9M17 7a2 2 0 0 1 4 0v8a7 7 0 0 1-7 7H10a4 4 0 0 1-4-4l-3-5 2-2 4 3',
    flag: 'M5 21V4M5 4h12l-2 5 2 5H5',
    edit: 'M4 20h4l11-11-4-4L4 16zM14 5l4 4',
    trash: 'M5 7h14M9 7V4h6v3M7 7v13h10V7',
    dots: 'M6 12h.01M12 12h.01M18 12h.01',
    lock: 'M6 11h12v10H6zM8 11V8a4 4 0 0 1 8 0v3',
    globe: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18',
    cross: 'M10 2h4v8h8v4h-8v8h-4v-8H2v-4h8z',
    leaf: 'M21 3c0 9-6 18-15 18 0-9 6-18 15-18zM6 21l9-9',
    mail: 'M3 6h18v12H3zM3 6l9 7 9-7',
    phone: 'M5 4h4l2 5-3 2a12 12 0 0 0 5 5l2-3 5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z',
    map_pin: 'M12 22s7-7 7-13a7 7 0 0 0-14 0c0 6 7 13 7 13zM12 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4z',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2',
    filter: 'M3 5h18l-7 9v6l-4-2v-4z',
    grid: 'M3 3h8v8H3zM13 3h8v8h-8zM3 13h8v8H3zM13 13h8v8h-8z',
    list: 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
    star: 'M12 3l2.5 6 6.5.5-5 4.5L18 21l-6-3.5L6 21l1.5-7-5-4.5 6.5-.5z',
    upload: 'M12 16V4M5 11l7-7 7 7M4 20h16',
    download: 'M12 4v12M5 13l7 7 7-7M4 20h16',
    shield: 'M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z',
    flame: 'M12 22a6 6 0 0 1-6-6c0-4 3-6 3-10 3 1 5 4 5 7 1-1 2-3 2-5 3 2 4 5 4 8a6 6 0 0 1-8 6z',
    moon: 'M21 12a9 9 0 1 1-9-9 7 7 0 0 0 9 9z',
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={style}>
      <path d={paths[name] || paths.home} />
    </svg>
  );
};

// ─── Avatar ────────────────────────────────────────────────────────
const Avatar = ({ name = '?', size = 'md', tone, anonymous = false }) => {
  const cls = size === 'sm' ? 'avatar avatar-sm' : size === 'lg' ? 'avatar avatar-lg' : size === 'xl' ? 'avatar avatar-xl' : 'avatar';
  if (anonymous) {
    return <div className={cls} style={{ background: '#dcd6c5', color: '#6b7d6e' }}><Icon name="user" size={size === 'lg' ? 20 : 14} /></div>;
  }
  const palettes = [
    { bg: '#dde7d8', fg: '#2f5a45' },
    { bg: '#efe2c4', fg: '#7a5a2c' },
    { bg: '#dde7e8', fg: '#3e5d63' },
    { bg: '#e8dde6', fg: '#6a4a64' },
    { bg: '#ecd9c9', fg: '#7a4a2e' },
    { bg: '#d9e5dc', fg: '#3e5e48' },
  ];
  const p = palettes[(name.charCodeAt(0) || 0) % palettes.length];
  const initials = name.split(' ').map(s => s[0]).slice(0, 2).join('').toUpperCase();
  return <div className={cls} style={{ background: tone?.bg || p.bg, color: tone?.fg || p.fg }}>{initials}</div>;
};

// ─── Badge ────────────────────────────────────────────────────────
const RoomBadge = ({ room }) => {
  const tints = {
    Prayer:    { bg: 'var(--r-prayer-bg)', fg: 'var(--r-prayer-fg)', ic: 'hand' },
    Testimony: { bg: 'var(--r-testimony-bg)', fg: 'var(--r-testimony-fg)', ic: 'sparkle' },
    Bible_Study: { bg: 'var(--r-study-bg)', fg: 'var(--r-study-fg)', ic: 'book' },
    Questions: { bg: 'var(--r-questions-bg)', fg: 'var(--r-questions-fg)', ic: 'chat' },
    Encourage: { bg: 'var(--r-encourage-bg)', fg: 'var(--r-encourage-fg)', ic: 'heart' },
    Youth: { bg: 'var(--r-youth-bg)', fg: 'var(--r-youth-fg)', ic: 'flame' },
  };
  const key = room.replace(' ', '_');
  const t = tints[key] || tints.Prayer;
  return (
    <span className="badge badge-room" style={{ background: t.bg, color: t.fg, borderColor: 'transparent' }}>
      <Icon name={t.ic} size={11} />{room}
    </span>
  );
};

// ─── Reaction picker ────────────────────────────────────────────────
const REACTIONS = [
  { id: 'amen', em: '🙏', label: 'Amen' },
  { id: 'praying', em: '🕊', label: 'Praying' },
  { id: 'encourage', em: '✨', label: 'Be Encouraged' },
  { id: 'love', em: '❤️', label: 'Love' },
  { id: 'inspired', em: '🌿', label: 'Inspired' },
];
const ReactionRow = ({ counts = {}, active }) => (
  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
    {REACTIONS.map(r => (
      <button key={r.id} className={'rxn' + (active === r.id ? ' active' : '')}>
        <span className="em">{r.em}</span>
        <span>{r.label}</span>
        {counts[r.id] != null && <span className="muted">·{counts[r.id]}</span>}
      </button>
    ))}
  </div>
);
const ReactionSummary = ({ counts = {}, total }) => (
  <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
    <span style={{ display: 'inline-flex' }}>
      {Object.keys(counts).slice(0, 3).map((k, i) => {
        const r = REACTIONS.find(x => x.id === k);
        return r ? <span key={k} style={{ marginLeft: i === 0 ? 0 : -4, fontSize: 13 }}>{r.em}</span> : null;
      })}
    </span>
    <span className="muted tiny">{total}</span>
  </div>
);

// ─── Post Card ────────────────────────────────────────────────────
const PostCard = ({ post, variant = 'default' }) => {
  const isAnon = post.anonymous;
  return (
    <article className="card" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
      <header style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Avatar name={isAnon ? '?' : post.author} size="sm" anonymous={isAnon} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
            <span style={{ fontWeight: 600 }}>{isAnon ? 'Anonymous' : post.author}</span>
            {post.role === 'mod' && <span className="badge badge-mod" style={{ height: 18, fontSize: 10 }}>Moderator</span>}
            <span className="muted">·</span>
            <span className="muted tiny">{post.time}</span>
            {post.featured && <><span className="muted">·</span><span style={{ color: 'var(--accent)', fontSize: 12, display: 'inline-flex', alignItems: 'center', gap: 3 }}><Icon name="pin" size={11} /> Featured</span></>}
          </div>
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>
            <RoomBadge room={post.room} />
          </div>
        </div>
        <button className="btn btn-ghost btn-icon btn-sm" aria-label="more"><Icon name="dots" size={16} /></button>
      </header>

      <div>
        <h3 style={{ font: '600 17px var(--font-sans)', letterSpacing: '-0.01em', marginBottom: 6 }}>{post.title}</h3>
        <p style={{ margin: 0, color: 'var(--ink-2)', fontSize: 14, lineHeight: 1.55 }}>{post.excerpt}</p>
      </div>

      {post.image && (
        <div style={{ borderRadius: 10, overflow: 'hidden', aspectRatio: '16/9', background: 'repeating-linear-gradient(135deg, var(--bg-2), var(--bg-2) 8px, var(--surface-2) 8px, var(--surface-2) 16px)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 11 }}>
          [{post.image}]
        </div>
      )}

      {post.tags && (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {post.tags.map(t => <span key={t} className="muted tiny" style={{ fontFamily: 'var(--font-mono)' }}>#{t}</span>)}
        </div>
      )}

      <footer style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: 4 }}>
        <ReactionSummary counts={post.reactions || {}} total={post.reactionTotal} />
        <div style={{ display: 'flex', gap: 4, color: 'var(--muted)' }}>
          <button className="btn btn-ghost btn-sm" style={{ gap: 5 }}><Icon name="chat" size={14} /> {post.comments}</button>
          <button className="btn btn-ghost btn-sm" style={{ gap: 5 }}><Icon name="repost" size={14} /> {post.reshares || 0}</button>
          <button className="btn btn-ghost btn-sm btn-icon" aria-label="bookmark"><Icon name="bookmark" size={14} /></button>
        </div>
      </footer>
    </article>
  );
};

// ─── App Shell (top nav) ─────────────────────────────────────────
const TopNav = ({ active = 'feed', notifications = 3, user = 'Sarah' }) => (
  <nav style={{ height: 56, borderBottom: '1px solid var(--border-2)', background: 'var(--surface)', display: 'flex', alignItems: 'center', padding: '0 24px', gap: 16, position: 'sticky', top: 0, zIndex: 10 }}>
    <a style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--primary)', textDecoration: 'none' }}>
      <span style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--primary)', color: 'var(--surface)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon name="cross" size={14} stroke={2} />
      </span>
      <span style={{ font: '500 17px var(--font-display)', letterSpacing: '-0.02em', color: 'var(--ink)' }}>Faith Community</span>
    </a>
    <div style={{ flex: 1, display: 'flex', justifyContent: 'center', gap: 2 }}>
      {[
        { id: 'feed', icon: 'feed', label: 'Feed' },
        { id: 'rooms', icon: 'rooms', label: 'Rooms' },
        { id: 'resources', icon: 'book', label: 'Library' },
        { id: 'connections', icon: 'users', label: 'Connections' },
      ].map(item => (
        <a key={item.id} style={{
          display: 'inline-flex', alignItems: 'center', gap: 6, padding: '7px 12px', borderRadius: 8,
          font: '500 13.5px var(--font-sans)',
          color: active === item.id ? 'var(--ink)' : 'var(--muted)',
          background: active === item.id ? 'var(--surface-2)' : 'transparent',
          textDecoration: 'none', cursor: 'pointer',
        }}>
          <Icon name={item.icon} size={15} /> {item.label}
        </a>
      ))}
    </div>
    <div style={{ position: 'relative', width: 280 }}>
      <Icon name="search" size={14} style={{ position: 'absolute', left: 10, top: 11, color: 'var(--muted)' }} />
      <input className="input" placeholder="Search posts, people, resources" style={{ paddingLeft: 32, height: 34, fontSize: 13 }} />
      <kbd style={{ position: 'absolute', right: 8, top: 8, fontSize: 10, fontFamily: 'var(--font-mono)', color: 'var(--muted)', border: '1px solid var(--border)', borderRadius: 4, padding: '1px 5px', background: 'var(--bg)' }}>⌘K</kbd>
    </div>
    <button className="btn btn-primary btn-sm" style={{ gap: 5 }}><Icon name="plus" size={14} /> New post</button>
    <button className="btn btn-ghost btn-icon" style={{ position: 'relative' }}>
      <Icon name="bell" size={16} />
      {notifications > 0 && <span style={{ position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: 999, background: 'var(--accent)', border: '2px solid var(--surface)' }} />}
    </button>
    <button className="btn btn-ghost btn-icon"><Icon name="bookmark" size={16} /></button>
    <Avatar name={user} size="sm" />
  </nav>
);

const MobileTopBar = ({ title = 'Feed' }) => (
  <div style={{ height: 52, borderBottom: '1px solid var(--border-2)', background: 'var(--surface)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 16px' }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{ width: 26, height: 26, borderRadius: 7, background: 'var(--primary)', color: 'var(--surface)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="cross" size={13} stroke={2} /></span>
      <span style={{ font: '500 16px var(--font-display)' }}>{title}</span>
    </div>
    <div style={{ display: 'flex', gap: 4 }}>
      <button className="btn btn-ghost btn-icon btn-sm"><Icon name="search" size={15} /></button>
      <button className="btn btn-ghost btn-icon btn-sm" style={{ position: 'relative' }}>
        <Icon name="bell" size={15} />
        <span style={{ position: 'absolute', top: 4, right: 4, width: 7, height: 7, borderRadius: 999, background: 'var(--accent)' }} />
      </button>
    </div>
  </div>
);

const MobileBottomNav = ({ active = 'feed' }) => (
  <div style={{ height: 64, borderTop: '1px solid var(--border-2)', background: 'var(--surface)', display: 'flex', alignItems: 'stretch', padding: '0 4px' }}>
    {[
      { id: 'feed', icon: 'feed', label: 'Feed' },
      { id: 'rooms', icon: 'rooms', label: 'Rooms' },
      { id: 'create', icon: 'plus', label: '' },
      { id: 'resources', icon: 'book', label: 'Library' },
      { id: 'profile', icon: 'user', label: 'You' },
    ].map(item => {
      const isCreate = item.id === 'create';
      return (
        <button key={item.id} style={{
          flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 3,
          background: 'transparent', border: 0, cursor: 'pointer', padding: 0,
          color: active === item.id ? 'var(--ink)' : 'var(--muted)',
        }}>
          {isCreate ? (
            <span style={{ width: 44, height: 36, borderRadius: 12, background: 'var(--primary)', color: 'var(--surface)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="plus" size={18} stroke={2} />
            </span>
          ) : (
            <>
              <Icon name={item.icon} size={20} />
              <span style={{ fontSize: 10.5, fontWeight: 500 }}>{item.label}</span>
            </>
          )}
        </button>
      );
    })}
  </div>
);

// ─── Page Header ──────────────────────────────────────────────
const PageHeader = ({ title, subtitle, children, breadcrumb }) => (
  <header style={{ padding: '20px 24px 16px', borderBottom: '1px solid var(--border-2)' }}>
    {breadcrumb && <div className="muted tiny" style={{ marginBottom: 6 }}>{breadcrumb}</div>}
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 16 }}>
      <div>
        <h1 className="page-title" style={{ fontSize: 20 }}>{title}</h1>
        {subtitle && <div className="page-sub">{subtitle}</div>}
      </div>
      {children && <div style={{ display: 'flex', gap: 8 }}>{children}</div>}
    </div>
  </header>
);

// Empty state
const EmptyState = ({ icon = 'leaf', title, body, cta }) => (
  <div style={{ padding: '48px 24px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
    <div style={{ width: 56, height: 56, borderRadius: 999, background: 'var(--surface-2)', color: 'var(--muted)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', border: '1px solid var(--border-2)' }}>
      <Icon name={icon} size={22} />
    </div>
    <div style={{ font: '600 15px var(--font-sans)' }}>{title}</div>
    <div className="muted" style={{ maxWidth: 320, lineHeight: 1.5 }}>{body}</div>
    {cta && <div style={{ marginTop: 4 }}>{cta}</div>}
  </div>
);

Object.assign(window, {
  Icon, Avatar, RoomBadge, REACTIONS, ReactionRow, ReactionSummary,
  PostCard, TopNav, MobileTopBar, MobileBottomNav, PageHeader, EmptyState,
});
